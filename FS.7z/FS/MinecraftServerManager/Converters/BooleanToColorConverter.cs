using System;
using System.Globalization;
using System.Windows.Data;
using System.Windows.Media;
using MinecraftServerManager.Utils;

namespace MinecraftServerManager.Converters
{
    public class BooleanToColorConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            bool boolValue = (bool)value;
            string colorParameters = parameter as string;
            
            if (!StringUtils.IsNullOrEmpty(colorParameters))
            {
                string[] colors = colorParameters.Split('|');
                if (colors.Length >= 2)
                {
                    string colorString = boolValue ? colors[0] : colors[1];
                    return new BrushConverter().ConvertFrom(colorString);
                }
            }
            
            // Значения по умолчанию
            return boolValue 
                ? new SolidColorBrush(Colors.Green) 
                : new SolidColorBrush(Colors.Red);
        }

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            throw new NotImplementedException();
        }
    }
} 