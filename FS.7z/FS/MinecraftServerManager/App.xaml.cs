using System;
using System.IO;
using System.Windows;
using System.Diagnostics;
using System.Windows.Threading;

namespace MinecraftServerManager
{
    /// <summary>
    /// Логика взаимодействия для App.xaml
    /// </summary>
    public partial class App : Application
    {
        public static string AppDataPath { get; private set; }
        public static string LogFilePath { get; private set; }

        protected override void OnStartup(StartupEventArgs e)
        {
            try
            {
                Trace.WriteLine("[APP-START] Начало запуска приложения");
                
                // Проверяем инициализацию ресурсов
                try
                {
                    Trace.WriteLine("[APP-RESOURCES] Проверка доступа к ресурсам...");
                    if (Resources != null)
                    {
                        Trace.WriteLine("[APP-RESOURCES] Ресурсы приложения инициализированы");
                    }
                }
                catch (Exception resEx)
                {
                    Trace.WriteLine($"[APP-RESOURCES-ERROR] Ошибка при проверке ресурсов: {resEx.Message}");
                }
                
                // Вызываем базовую инициализацию после проверки ресурсов
                base.OnStartup(e);

                // Настраиваем директорию данных приложения
                AppDataPath = Path.Combine(
                    Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData),
                    "MinecraftServerManager");
                Trace.WriteLine($"[APP-PATH] Путь к данным приложения: {AppDataPath}");

                // Создаем директорию для хранения данных приложения, если ее нет
                if (!Directory.Exists(AppDataPath))
                {
                    Trace.WriteLine("[APP-DIR] Создание основной директории данных");
                    Directory.CreateDirectory(AppDataPath);
                }

                // Создаем директорию для скачанных ядер серверов
                string serversPath = Path.Combine(AppDataPath, "Servers");
                if (!Directory.Exists(serversPath))
                {
                    Trace.WriteLine("[APP-DIR] Создание директории для серверов");
                    Directory.CreateDirectory(serversPath);
                }

                // Настраиваем логирование
                SetupLogging();

                // Логируем запуск приложения
                Trace.WriteLine($"[APP-INIT] Приложение инициализировано: {DateTime.Now}");
                Trace.WriteLine($"[APP-INIT] Директория данных: {AppDataPath}");
                Trace.WriteLine("[APP-INIT] Настройка обработчиков исключений");

                // Обработка необработанных исключений в домене
                AppDomain.CurrentDomain.UnhandledException += (sender, args) =>
                {
                    var ex = args.ExceptionObject as Exception;
                    Trace.WriteLine($"[CRITICAL] КРИТИЧЕСКАЯ ОШИБКА: {ex?.Message}");
                    Trace.WriteLine($"[CRITICAL] StackTrace: {ex?.StackTrace}");
                    MessageBox.Show($"Произошла критическая ошибка: {ex?.Message}\n\nStackTrace: {ex?.StackTrace}", "Ошибка", 
                        MessageBoxButton.OK, MessageBoxImage.Error);
                };

                // Перехват исключений в UI потоке с деталями стека
                DispatcherUnhandledException += (sender, args) =>
                {
                    Trace.WriteLine($"[UI-ERROR] Необработанное исключение UI: {args.Exception.Message}");
                    Trace.WriteLine($"[UI-ERROR] StackTrace: {args.Exception.StackTrace}");
                    MessageBox.Show($"Произошла ошибка: {args.Exception.Message}\n\nStackTrace: {args.Exception.StackTrace}", "Ошибка", 
                        MessageBoxButton.OK, MessageBoxImage.Error);
                    args.Handled = true;
                };
                
                Trace.WriteLine("[APP-READY] Приложение готово к запуску основного окна");
            }
            catch (Exception ex)
            {
                Trace.WriteLine($"[STARTUP-ERROR] Ошибка при запуске приложения: {ex.Message}");
                Trace.WriteLine($"[STARTUP-ERROR] StackTrace: {ex.StackTrace}");
                MessageBox.Show($"Ошибка при запуске приложения: {ex.Message}\n\nStackTrace: {ex.StackTrace}", "Критическая ошибка", 
                    MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void SetupLogging()
        {
            try
            {
                // Создаем директорию для логов, если не существует
                string logDirectory = Path.Combine(AppDataPath, "Logs");
                if (!Directory.Exists(logDirectory))
                {
                    Directory.CreateDirectory(logDirectory);
                }
                
                // Создаем файл лога с текущей датой и временем
                string timestamp = DateTime.Now.ToString("yyyy-MM-dd_HH-mm-ss");
                LogFilePath = Path.Combine(logDirectory, $"log_{timestamp}.txt");
                
                // Создаем слушатель для записи в файл
                TextWriterTraceListener textListener = new TextWriterTraceListener(LogFilePath);
                
                // Добавляем текстовый слушатель для Trace
                Trace.Listeners.Add(textListener);
                
                // Включаем автоматический сброс данных после каждой записи
                Trace.AutoFlush = true;
                
                // Записываем заголовок лога
                Trace.WriteLine("========================================");
                Trace.WriteLine($"Лог сессии MinecraftServerManager ({timestamp})");
                Trace.WriteLine($"Операционная система: {Environment.OSVersion}");
                Trace.WriteLine($".NET Framework: {Environment.Version}");
                Trace.WriteLine("========================================");
                
                Trace.WriteLine("[LOG-INIT] Логирование успешно настроено");
            }
            catch (Exception ex)
            {
                // Не можем использовать логирование здесь, так как оно еще не настроено
                MessageBox.Show($"Не удалось настроить логирование: {ex.Message}", "Предупреждение", 
                    MessageBoxButton.OK, MessageBoxImage.Warning);
            }
        }
    }
} 