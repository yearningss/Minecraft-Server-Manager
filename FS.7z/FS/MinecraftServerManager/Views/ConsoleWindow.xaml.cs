using System;
using System.IO;
using System.Windows;
using System.Windows.Input;
using System.Windows.Threading;
using System.Diagnostics;
using System.Text;
using System.Text.RegularExpressions;
using Microsoft.Win32;
using MinecraftServerManager.Models;

namespace MinecraftServerManager.Views
{
    /// <summary>
    /// Логика взаимодействия для ConsoleWindow.xaml
    /// </summary>
    public partial class ConsoleWindow : Window
    {
        private Process _serverProcess;
        private StringBuilder _logContent = new StringBuilder();
        private DispatcherTimer _scrollTimer;
        private DispatcherTimer _uptimeTimer;
        private bool _autoScroll = true;
        private string _serverName;
        
        // Добавляем статус сервера
        public ServerStatus ServerStatus { get; } = new ServerStatus();

        // Регулярные выражения для парсинга логов
        private readonly Regex _playerJoinRegex = new Regex(@"(\w+)\[/[0-9.:]+\] logged in", RegexOptions.Compiled);
        private readonly Regex _playerLeaveRegex = new Regex(@"(\w+) left the game", RegexOptions.Compiled);
        private readonly Regex _playerCountRegex = new Regex(@"There are (\d+) of a max of (\d+) players online", RegexOptions.Compiled);
        private readonly Regex _versionRegex = new Regex(@"Starting minecraft server version (.+)", RegexOptions.Compiled);

        public ConsoleWindow(string serverName, string serverPath)
        {
            InitializeComponent();
            
            DataContext = ServerStatus;

            _serverName = serverName;
            HeaderText.Text = $"Консоль сервера: {serverName}";
            
            // Настройка таймера для автоматической прокрутки
            _scrollTimer = new DispatcherTimer();
            _scrollTimer.Interval = TimeSpan.FromMilliseconds(500);
            _scrollTimer.Tick += (s, e) => ScrollToEnd();
            _scrollTimer.Start();
            
            // Таймер для обновления времени работы сервера
            _uptimeTimer = new DispatcherTimer();
            _uptimeTimer.Interval = TimeSpan.FromSeconds(1);
            _uptimeTimer.Tick += (s, e) => ServerStatus.OnPropertyChanged(nameof(ServerStatus.UptimeText));
            _uptimeTimer.Start();

            // Обработчик закрытия окна
            Closing += ConsoleWindow_Closing;

            // Запуск сервера
            StartServer(serverPath);
        }

        private void StartServer(string serverPath)
        {
            try
            {
                _serverProcess = new Process();
                
                // Настройка информации о процессе
                _serverProcess.StartInfo.FileName = "java";
                _serverProcess.StartInfo.Arguments = "-jar server.jar nogui";
                _serverProcess.StartInfo.WorkingDirectory = serverPath;
                _serverProcess.StartInfo.UseShellExecute = false;
                _serverProcess.StartInfo.CreateNoWindow = true;
                
                // Перенаправление стандартных потоков
                _serverProcess.StartInfo.RedirectStandardOutput = true;
                _serverProcess.StartInfo.RedirectStandardError = true;
                _serverProcess.StartInfo.RedirectStandardInput = true;
                
                // Кодировка для корректного отображения кириллицы
                _serverProcess.StartInfo.StandardOutputEncoding = Encoding.UTF8;
                _serverProcess.StartInfo.StandardErrorEncoding = Encoding.UTF8;
                
                // Асинхронная обработка вывода
                _serverProcess.OutputDataReceived += ServerProcess_OutputDataReceived;
                _serverProcess.ErrorDataReceived += ServerProcess_ErrorDataReceived;
                
                // Обработка завершения процесса
                _serverProcess.EnableRaisingEvents = true;
                _serverProcess.Exited += ServerProcess_Exited;
                
                // Запуск процесса
                _serverProcess.Start();
                
                // Начало асинхронного считывания
                _serverProcess.BeginOutputReadLine();
                _serverProcess.BeginErrorReadLine();
                
                // Обновляем статус
                ServerStatus.IsRunning = true;
                ServerStatus.MaxPlayers = 20; // По умолчанию
                
                // Информационное сообщение
                AppendToConsole("Сервер запускается...\n");
                AppendToConsole("-----------------------------------------------------\n");
            }
            catch (Exception ex)
            {
                AppendToConsole($"Ошибка при запуске сервера: {ex.Message}\n");
                
                // Обновляем статус
                ServerStatus.IsRunning = false;
                
                // Проверка наличия Java
                AppendToConsole("Проверка наличия Java в системе...\n");
                CheckJavaInstallation();
            }
        }

        private void ServerProcess_Exited(object sender, EventArgs e)
        {
            Dispatcher.Invoke(() =>
            {
                AppendToConsole("Сервер завершил работу.\n");
                ServerStatus.IsRunning = false;
            });
        }

        private void CheckJavaInstallation()
        {
            try
            {
                Process javaCheck = new Process();
                javaCheck.StartInfo.FileName = "java";
                javaCheck.StartInfo.Arguments = "-version";
                javaCheck.StartInfo.UseShellExecute = false;
                javaCheck.StartInfo.RedirectStandardError = true;
                javaCheck.StartInfo.CreateNoWindow = true;
                
                javaCheck.Start();
                string javaVersion = javaCheck.StandardError.ReadToEnd();
                javaCheck.WaitForExit();
                
                AppendToConsole($"Информация о Java: {javaVersion}\n");
            }
            catch
            {
                AppendToConsole("Java не установлена или не найдена в системе!\n");
                AppendToConsole("Пожалуйста, установите Java с официального сайта: https://www.java.com/download/\n");
            }
        }

        private void ServerProcess_OutputDataReceived(object sender, DataReceivedEventArgs e)
        {
            if (!string.IsNullOrEmpty(e.Data))
            {
                Dispatcher.Invoke(() => 
                {
                    AppendToConsole(e.Data + "\n");
                    ProcessLogLine(e.Data);
                });
            }
        }

        private void ServerProcess_ErrorDataReceived(object sender, DataReceivedEventArgs e)
        {
            if (!string.IsNullOrEmpty(e.Data))
            {
                Dispatcher.Invoke(() => 
                {
                    AppendToConsole($"[ERROR] {e.Data}\n");
                    ProcessLogLine(e.Data);
                });
            }
        }

        private void ProcessLogLine(string line)
        {
            // Обновляем последнюю строку лога
            ServerStatus.LastLog = line;
            
            // Проверяем версию сервера
            var versionMatch = _versionRegex.Match(line);
            if (versionMatch.Success)
            {
                ServerStatus.Version = versionMatch.Groups[1].Value;
            }
            
            // Проверяем количество игроков
            var playerCountMatch = _playerCountRegex.Match(line);
            if (playerCountMatch.Success)
            {
                ServerStatus.PlayersOnline = int.Parse(playerCountMatch.Groups[1].Value);
                ServerStatus.MaxPlayers = int.Parse(playerCountMatch.Groups[2].Value);
            }
            
            // Проверяем вход игрока
            var joinMatch = _playerJoinRegex.Match(line);
            if (joinMatch.Success)
            {
                ServerStatus.PlayersOnline++;
                string playerName = joinMatch.Groups[1].Value;
                AppendToConsole($"[INFO] Игрок {playerName} присоединился к серверу\n");
            }
            
            // Проверяем выход игрока
            var leaveMatch = _playerLeaveRegex.Match(line);
            if (leaveMatch.Success && ServerStatus.PlayersOnline > 0)
            {
                ServerStatus.PlayersOnline--;
                string playerName = leaveMatch.Groups[1].Value;
                AppendToConsole($"[INFO] Игрок {playerName} покинул сервер\n");
            }
        }

        private void AppendToConsole(string text)
        {
            ConsoleOutput.AppendText(text);
            _logContent.Append(text);
            
            if (_autoScroll)
            {
                ScrollToEnd();
            }
        }

        private void ScrollToEnd()
        {
            ConsoleScrollViewer.ScrollToEnd();
        }

        private void SendCommand(string command)
        {
            if (_serverProcess != null && !_serverProcess.HasExited)
            {
                try
                {
                    AppendToConsole($"> {command}\n");
                    _serverProcess.StandardInput.WriteLine(command);
                    _serverProcess.StandardInput.Flush();
                }
                catch (Exception ex)
                {
                    AppendToConsole($"Ошибка при отправке команды: {ex.Message}\n");
                }
            }
            else
            {
                AppendToConsole("Сервер не запущен или не отвечает.\n");
            }
        }

        private void ConsoleWindow_Closing(object sender, System.ComponentModel.CancelEventArgs e)
        {
            // Спрашиваем пользователя хочет ли он закрыть консоль и сервер
            if (_serverProcess != null && !_serverProcess.HasExited)
            {
                MessageBoxResult result = MessageBox.Show(
                    "Вы уверены, что хотите закрыть консоль? Это завершит работу сервера.",
                    "Подтверждение закрытия",
                    MessageBoxButton.YesNo,
                    MessageBoxImage.Question);

                if (result == MessageBoxResult.No)
                {
                    e.Cancel = true;
                    return;
                }

                // Отправляем команду на корректное завершение сервера
                try
                {
                    SendCommand("stop");
                    // Ждем небольшое время для корректного завершения
                    if (!_serverProcess.WaitForExit(5000))
                    {
                        _serverProcess.Kill(); // Принудительно закрываем, если сервер не завершился корректно
                    }
                }
                catch
                {
                    // Ничего не делаем, если возникла ошибка при остановке сервера
                }
            }

            // Останавливаем таймеры
            _scrollTimer.Stop();
            _uptimeTimer.Stop();
        }

        private void CommandInput_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Enter)
            {
                string command = CommandInput.Text.Trim();
                if (!string.IsNullOrEmpty(command))
                {
                    SendCommand(command);
                    CommandInput.Clear();
                }
                e.Handled = true;
            }
        }

        private void SendCommandButton_Click(object sender, RoutedEventArgs e)
        {
            string command = CommandInput.Text.Trim();
            if (!string.IsNullOrEmpty(command))
            {
                SendCommand(command);
                CommandInput.Clear();
            }
        }

        private void ClearConsoleButton_Click(object sender, RoutedEventArgs e)
        {
            ConsoleOutput.Clear();
        }

        private void SaveLogsButton_Click(object sender, RoutedEventArgs e)
        {
            SaveFileDialog saveDialog = new SaveFileDialog
            {
                Filter = "Текстовые файлы (*.txt)|*.txt|Все файлы (*.*)|*.*",
                FileName = $"server-log-{_serverName}-{DateTime.Now:yyyy-MM-dd-HH-mm}.txt"
            };

            if (saveDialog.ShowDialog() == true)
            {
                try
                {
                    File.WriteAllText(saveDialog.FileName, _logContent.ToString());
                    MessageBox.Show(
                        $"Логи успешно сохранены в файл:\n{saveDialog.FileName}",
                        "Сохранение логов",
                        MessageBoxButton.OK,
                        MessageBoxImage.Information);
                }
                catch (Exception ex)
                {
                    MessageBox.Show(
                        $"Ошибка при сохранении логов: {ex.Message}",
                        "Ошибка",
                        MessageBoxButton.OK,
                        MessageBoxImage.Error);
                }
            }
        }
    }
} 