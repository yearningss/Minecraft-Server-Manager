using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Linq;
using Newtonsoft.Json;
using MinecraftServerManager.Models;
using System.Threading;
using System.Diagnostics;

namespace MinecraftServerManager.Services
{
    public class VersionService
    {
        private readonly HttpClient _httpClient;
        private const string MOJANG_VERSION_MANIFEST_URL = "https://launchermeta.mojang.com/mc/game/version_manifest.json";
        private const string PAPER_API_URL = "https://api.papermc.io/v2/projects/paper";
        private const string SPIGOT_BASE_URL = "https://download.getbukkit.org/spigot/";
        private const string PURPUR_API_URL = "https://api.purpurmc.org/v2/purpur";
        private const string PUFFERFISH_API_URL = "https://ci.pufferfish.host/job/Pufferfish-1.20"; // Пример для 1.20
        private const string LEAF_API_URL = "https://leaf.une.edu.au/download/";
        private const string CRAFTBUKKIT_BASE_URL = "https://download.getbukkit.org/craftbukkit/";
        private const string VELOCITY_API_URL = "https://api.papermc.io/v2/projects/velocity";
        private const string NULLCORDX_API_URL = "https://github.com/NullCordX/NullCordX/releases";
        private const string BUNGEECORD_API_URL = "https://ci.md-5.net/job/BungeeCord/";
        private const string WATERFALL_API_URL = "https://api.papermc.io/v2/projects/waterfall";
        private const string FORGE_API_URL = "https://files.minecraftforge.net/net/minecraftforge/forge/";
        private const string FABRIC_API_URL = "https://meta.fabricmc.net/v2/versions/loader";
        private const string QUILT_API_URL = "https://meta.quiltmc.org/v3/versions/loader";
        private const string NEOFORGE_API_URL = "https://maven.neoforged.net/releases/net/neoforged/neoforge/";

        // Кэш для хранения версий
        private static Dictionary<string, List<MinecraftVersion>> _versionCache;
        private static DateTime _cacheTimestamp = DateTime.MinValue;
        private static readonly TimeSpan _cacheDuration = TimeSpan.FromHours(1);
        private static SemaphoreSlim _cacheLock = new SemaphoreSlim(1, 1);

        public VersionService()
        {
            _httpClient = new HttpClient();
            _httpClient.DefaultRequestHeaders.Add("User-Agent", "MinecraftServerManager/1.0");
            _httpClient.Timeout = TimeSpan.FromSeconds(30); // Увеличиваем таймаут для более стабильной работы
            Trace.WriteLine($"[INIT] VersionService создан с таймаутом {_httpClient.Timeout.TotalSeconds} сек.");
        }

        /// <summary>
        /// Получает список всех версий Minecraft из манифеста Mojang
        /// </summary>
        public async Task<MinecraftVersionInfo> GetVanillaVersionsAsync()
        {
            try
            {
                var response = await _httpClient.GetStringAsync(MOJANG_VERSION_MANIFEST_URL);
                var manifestData = JsonConvert.DeserializeObject<dynamic>(response);

                var versionInfo = new MinecraftVersionInfo
                {
                    LatestRelease = manifestData.latest.release,
                    LatestSnapshot = manifestData.latest.snapshot
                };

                // Загружаем больше версий, чтобы отобразить все доступные
                var versionsToLoad = 50; // Увеличиваем до 50 последних версий
                var versionEntries = ((IEnumerable<dynamic>)manifestData.versions).Take(versionsToLoad);

                foreach (var versionEntry in versionEntries)
                {
                    string id = versionEntry.id;
                    string type = versionEntry.type;
                    DateTime releaseTime = versionEntry.releaseTime;
                    string url = versionEntry.url;

                    try
                    {
                        // Получаем детальную информацию о версии для получения URL скачивания
                        string versionDetailsJson = await _httpClient.GetStringAsync((string)url);
                        var versionDetails = JsonConvert.DeserializeObject<dynamic>(versionDetailsJson);
                        string downloadUrl = versionDetails.downloads.server.url;

                        versionInfo.Versions.Add(new MinecraftVersion
                        {
                            Id = id,
                            Name = id,
                            Type = type,
                            ServerType = ServerType.Vanilla,
                            ReleaseDate = releaseTime,
                            DownloadUrl = downloadUrl
                        });
                    }
                    catch (Exception ex)
                    {
                        Trace.WriteLine($"Ошибка при получении деталей версии {id}: {ex.Message}");
                        // Продолжаем со следующей версией
                    }
                }

                return versionInfo;
            }
            catch (Exception ex)
            {
                Trace.WriteLine($"Ошибка при получении версий Vanilla: {ex.Message}");
                return new MinecraftVersionInfo(); // Пустой список
            }
        }

        /// <summary>
        /// Получает доступные версии Paper
        /// </summary>
        public async Task<List<MinecraftVersion>> GetPaperVersionsAsync()
        {
            try
            {
                var response = await _httpClient.GetStringAsync(PAPER_API_URL);
                var paperData = JsonConvert.DeserializeObject<dynamic>(response);
                
                var paperVersions = new List<MinecraftVersion>();
                var versions = (paperData.versions as IEnumerable<dynamic>).ToList();
                
                // Загружаем больше версий
                var recentVersions = versions.Take(30); // Увеличиваем количество версий до 30

                foreach (var version in recentVersions)
                {
                    string versionId = version.ToString();
                    
                    try
                    {
                        // Получаем данные о сборках для этой версии
                        string buildsUrl = $"{PAPER_API_URL}/versions/{versionId}";
                        var buildsResponse = await _httpClient.GetStringAsync(buildsUrl);
                        var buildsData = JsonConvert.DeserializeObject<dynamic>(buildsResponse);
                        
                        // Берем последнюю сборку
                        var builds = (buildsData.builds as IEnumerable<dynamic>).ToList();
                        if (builds.Count > 0)
                        {
                            int latestBuild = builds.Last();
                            
                            string downloadUrl = $"{PAPER_API_URL}/versions/{versionId}/builds/{latestBuild}/downloads/paper-{versionId}-{latestBuild}.jar";
                            
                            paperVersions.Add(new MinecraftVersion
                            {
                                Id = versionId,
                                Name = versionId,
                                ServerType = ServerType.Paper,
                                Type = ServerType.Paper.ToString(),
                                ReleaseDate = DateTime.Now,
                                DownloadUrl = downloadUrl
                            });
                        }
                    }
                    catch (Exception ex)
                    {
                        Trace.WriteLine($"Ошибка при получении деталей версии Paper {versionId}: {ex.Message}");
                        // Продолжаем со следующей версией
                    }
                }

                return paperVersions;
            }
            catch (Exception ex)
            {
                Trace.WriteLine($"Ошибка при получении версий Paper: {ex.Message}");
                return new List<MinecraftVersion>();
            }
        }

        /// <summary>
        /// Получает доступные версии Spigot (по списку популярных версий)
        /// </summary>
        public List<MinecraftVersion> GetSpigotVersions()
        {
            // Расширенный список версий Spigot
            var versions = new List<string> { 
                "1.21.1", "1.21", "1.20.6", "1.20.5", "1.20.4", "1.20.3", "1.20.2", "1.20.1", "1.20", 
                "1.19.4", "1.19.3", "1.19.2", "1.19.1", "1.19", 
                "1.18.2", "1.18.1", "1.18", 
                "1.17.1", "1.17", 
                "1.16.5", "1.16.4", "1.16.3", "1.16.2", "1.16.1", "1.16",
                "1.15.2", "1.15.1", "1.15",
                "1.14.4", "1.14.3", "1.14.2", "1.14.1", "1.14",
                "1.13.2", "1.13.1", "1.13",
                "1.12.2", "1.12.1", "1.12",
                "1.11.2", "1.11.1", "1.11",
                "1.10.2", "1.10.1", "1.10",
                "1.9.4", "1.9.2", "1.9",
                "1.8.8", "1.8.7", "1.8.3", "1.8"
            };
            return versions.Select(v => new MinecraftVersion
            {
                Id = v,
                Name = v,
                ServerType = ServerType.Spigot,
                Type = ServerType.Spigot.ToString(),
                ReleaseDate = DateTime.Now,
                DownloadUrl = $"{SPIGOT_BASE_URL}spigot-{v}.jar"
            }).ToList();
        }

        /// <summary>
        /// Получает доступные версии Purpur
        /// </summary>
        public async Task<List<MinecraftVersion>> GetPurpurVersionsAsync()
        {
            try
            {
                var response = await _httpClient.GetStringAsync(PURPUR_API_URL);
                var purpurData = JsonConvert.DeserializeObject<dynamic>(response);
                
                var purpurVersions = new List<MinecraftVersion>();
                var versions = (purpurData.versions as IEnumerable<dynamic>).ToList();
                
                // Загружаем все доступные версии
                foreach (var version in versions)
                {
                    string versionId = version.ToString();
                    
                    try
                    {
                        // Получаем данные о сборках для этой версии
                        string buildsUrl = $"{PURPUR_API_URL}/{versionId}";
                        var buildsResponse = await _httpClient.GetStringAsync(buildsUrl);
                        var buildsData = JsonConvert.DeserializeObject<dynamic>(buildsResponse);
                        
                        // Берем последнюю сборку
                        string latestBuild = buildsData.builds.latest;
                        
                        string downloadUrl = $"{PURPUR_API_URL}/{versionId}/{latestBuild}/download";
                        
                        purpurVersions.Add(new MinecraftVersion
                        {
                            Id = versionId,
                            Name = versionId,
                            ServerType = ServerType.Purpur,
                            Type = ServerType.Purpur.ToString(),
                            ReleaseDate = DateTime.Now,
                            DownloadUrl = downloadUrl
                        });
                    }
                    catch (Exception ex)
                    {
                        Trace.WriteLine($"Ошибка при получении деталей версии Purpur {versionId}: {ex.Message}");
                        // Продолжаем со следующей версией
                    }
                }

                return purpurVersions;
            }
            catch (Exception ex)
            {
                Trace.WriteLine($"Ошибка при получении версий Purpur: {ex.Message}");
                return new List<MinecraftVersion>();
            }
        }

        /// <summary>
        /// Получает доступные версии CraftBukkit (по списку популярных версий)
        /// </summary>
        public List<MinecraftVersion> GetCraftBukkitVersions()
        {
            // Расширенный список версий CraftBukkit
            var versions = new List<string> { 
                "1.21.1", "1.21", "1.20.6", "1.20.5", "1.20.4", "1.20.3", "1.20.2", "1.20.1", "1.20", 
                "1.19.4", "1.19.3", "1.19.2", "1.19.1", "1.19", 
                "1.18.2", "1.18.1", "1.18", 
                "1.17.1", "1.17", 
                "1.16.5", "1.16.4", "1.16.3", "1.16.2", "1.16.1", "1.16",
                "1.15.2", "1.15.1", "1.15",
                "1.14.4", "1.14.3", "1.14.2", "1.14.1", "1.14",
                "1.13.2", "1.13.1", "1.13",
                "1.12.2", "1.12.1", "1.12",
                "1.11.2", "1.11.1", "1.11",
                "1.10.2", "1.10", 
                "1.9.4", "1.9",
                "1.8.8", "1.8"
            };
            return versions.Select(v => new MinecraftVersion
            {
                Id = v,
                Name = v,
                ServerType = ServerType.CraftBukkit,
                Type = ServerType.CraftBukkit.ToString(),
                ReleaseDate = DateTime.Now,
                DownloadUrl = $"{CRAFTBUKKIT_BASE_URL}craftbukkit-{v}.jar"
            }).ToList();
        }

        /// <summary>
        /// Получает доступные версии Forge (заглушка, требуется реализация API)
        /// </summary>
        public List<MinecraftVersion> GetForgeVersions()
        {
            // Предопределенные версии Forge - не требуют сетевых запросов
            var versions = new List<string> { "1.20.4", "1.20.2", "1.20.1", "1.19.4", "1.19.2", "1.18.2", "1.16.5" };
            return versions.Select(v => new MinecraftVersion
            {
                Id = v,
                Name = v,
                ServerType = ServerType.Forge,
                Type = ServerType.Forge.ToString(),
                ReleaseDate = DateTime.Now,
                DownloadUrl = $"{FORGE_API_URL}index_{v}.html"
            }).ToList();
        }

        /// <summary>
        /// Получает доступные версии Fabric (оптимизированная версия)
        /// </summary>
        public async Task<List<MinecraftVersion>> GetFabricVersionsAsync()
        {
            try
            {
                // Получаем доступные версии игры
                var gameVersionsResponse = await _httpClient.GetStringAsync($"{FABRIC_API_URL}/game");
                var gameVersions = JsonConvert.DeserializeObject<dynamic>(gameVersionsResponse);
                
                var fabricVersions = new List<MinecraftVersion>();
                var stableVersions = new List<string>();
                
                // Берем только стабильные версии, ограничиваем количество версий
                int count = 0;
                foreach (var version in gameVersions)
                {
                    if (version.stable == true)
                    {
                        stableVersions.Add(version.version.ToString());
                        count++;
                        if (count >= 10) break; // Только 10 версий для ускорения
                    }
                }
                
                // Берем только последние 5 стабильных версий
                foreach (var gameVersion in stableVersions.Take(5))
                {
                    try
                    {
                        // Получаем последнюю версию лоадера для этой версии игры
                        var loaderVersionsResponse = await _httpClient.GetStringAsync($"{FABRIC_API_URL}?game={gameVersion}");
                        var loaderVersions = JsonConvert.DeserializeObject<dynamic>(loaderVersionsResponse);
                        
                        if (loaderVersions.Count > 0)
                        {
                            var latestLoader = loaderVersions[0];
                            string loaderVersion = latestLoader.loader.version;
                            
                            // Ссылка на сервер Fabric не прямая
                            string downloadUrl = $"https://fabricmc.net/use/server/?page=1&game={gameVersion}&loader={loaderVersion}";
                            
                            fabricVersions.Add(new MinecraftVersion
                            {
                                Id = gameVersion,
                                Name = gameVersion,
                                ServerType = ServerType.Fabric,
                                Type = ServerType.Fabric.ToString(),
                                ReleaseDate = DateTime.Now,
                                DownloadUrl = downloadUrl
                            });
                        }
                    }
                    catch (Exception ex)
                    {
                        Trace.WriteLine($"Ошибка при получении лоадера Fabric для {gameVersion}: {ex.Message}");
                        // Продолжаем со следующей версией
                    }
                }
                
                return fabricVersions;
            }
            catch (Exception ex)
            {
                Trace.WriteLine($"Ошибка при получении версий Fabric: {ex.Message}");
                return new List<MinecraftVersion>();
            }
        }

        /// <summary>
        /// Получает доступные версии Quilt
        /// </summary>
        public async Task<List<MinecraftVersion>> GetQuiltVersionsAsync()
        {
            try
            {
                var quiltVersions = new List<MinecraftVersion>();
                
                try
                {
                    var response = await _httpClient.GetStringAsync(QUILT_API_URL);
                    var quiltData = JsonConvert.DeserializeObject<dynamic>(response);
                    
                    // Ограничиваем количество версий для ускорения
                    var versions = ((IEnumerable<dynamic>)quiltData).Take(10).ToList();
                    
                    foreach (var version in versions)
                    {
                        try
                        {
                            string gameVersion = version.gameVersion;
                            string quiltVersion = version.version;
                            string loaderVersion = version.loader.version;
                            
                            string downloadUrl = $"https://meta.quiltmc.org/v3/versions/loader/{gameVersion}/{loaderVersion}/server/jar";
                            
                            quiltVersions.Add(new MinecraftVersion
                            {
                                Id = gameVersion,
                                Name = $"{gameVersion} (Quilt {quiltVersion})",
                                ServerType = ServerType.Quilt,
                                Type = ServerType.Quilt.ToString(),
                                ReleaseDate = DateTime.Now,
                                DownloadUrl = downloadUrl
                            });
                        }
                        catch (Exception ex)
                        {
                            Trace.WriteLine($"Ошибка при обработке версии Quilt: {ex.Message}");
                            // Продолжаем со следующей версией
                        }
                    }
                }
                catch (Exception ex)
                {
                    Trace.WriteLine($"Ошибка при получении списка версий Quilt: {ex.Message}");
                    // Добавляем заглушки для основных версий
                    var defaultVersions = new List<string> { "1.20.4", "1.20.2", "1.20.1", "1.19.4" };
                    foreach (var v in defaultVersions)
                    {
                        quiltVersions.Add(new MinecraftVersion
                        {
                            Id = v,
                            Name = $"{v} (Quilt)",
                            ServerType = ServerType.Quilt,
                            Type = ServerType.Quilt.ToString(),
                            ReleaseDate = DateTime.Now,
                            DownloadUrl = $"https://meta.quiltmc.org/v3/versions/loader/{v}/latest/server/jar"
                        });
                    }
                }
                
                return quiltVersions;
            }
            catch (Exception ex)
            {
                Trace.WriteLine($"Критическая ошибка при получении версий Quilt: {ex.Message}");
                return new List<MinecraftVersion>();
            }
        }
        
        /// <summary>
        /// Получает доступные версии NeoForge
        /// </summary>
        public List<MinecraftVersion> GetNeoForgeVersions()
        {
            try
            {
                // Предопределенные версии, так как нет простого API
                var versions = new List<string> { "1.20.4", "1.20.2", "1.20.1" };
                var neoforgeVersions = new List<MinecraftVersion>();
                
                foreach (var version in versions)
                {
                    string downloadUrl = $"{NEOFORGE_API_URL}{version}-latest/neoforge-{version}-installer.jar";
                    
                    neoforgeVersions.Add(new MinecraftVersion
                    {
                        Id = version,
                        Name = version,
                        ServerType = ServerType.NeoForge,
                        Type = ServerType.NeoForge.ToString(),
                        ReleaseDate = DateTime.Now,
                        DownloadUrl = downloadUrl
                    });
                }
                
                return neoforgeVersions;
            }
            catch (Exception ex)
            {
                Trace.WriteLine($"Ошибка при получении версий NeoForge: {ex.Message}");
                return new List<MinecraftVersion>();
            }
        }

        /// <summary>
        /// Получает доступные версии Pufferfish
        /// </summary>
        public List<MinecraftVersion> GetPufferfishVersions()
        {
            // Предопределенные версии, так как нет простого API
            var versions = new List<string> { "1.20.4", "1.20.2", "1.20.1", "1.19.4", "1.18.2" };
            return versions.Select(v => new MinecraftVersion
            {
                Id = v,
                Name = v,
                ServerType = ServerType.Pufferfish,
                Type = ServerType.Pufferfish.ToString(),
                ReleaseDate = DateTime.Now,
                DownloadUrl = $"{PUFFERFISH_API_URL.Replace("1.20", v)}/lastSuccessfulBuild/artifact/build/libs/pufferfish-{v}.jar"
            }).ToList();
        }

        /// <summary>
        /// Получает доступные версии Leaf
        /// </summary>
        public List<MinecraftVersion> GetLeafVersions()
        {
            // Предопределенные версии, так как нет простого API
            var versions = new List<string> { "1.20.4", "1.20.2", "1.20.1", "1.19.4", "1.19.2" };
            return versions.Select(v => new MinecraftVersion
            {
                Id = v,
                Name = v,
                ServerType = ServerType.Leaf,
                Type = ServerType.Leaf.ToString(),
                ReleaseDate = DateTime.Now,
                DownloadUrl = $"{LEAF_API_URL}leaf-{v}.jar"
            }).ToList();
        }

        /// <summary>
        /// Получает доступные версии прокси-серверов (BungeeCord, Waterfall, Velocity)
        /// </summary>
        public async Task<List<MinecraftVersion>> GetProxyVersionsAsync(ServerType proxyType)
        {
            try
            {
                string apiUrl;
                string prefix;
                
                switch (proxyType)
                {
                    case ServerType.Velocity:
                        apiUrl = VELOCITY_API_URL;
                        prefix = "velocity";
                        break;
                    case ServerType.Waterfall:
                        apiUrl = WATERFALL_API_URL;
                        prefix = "waterfall";
                        break;
                    case ServerType.BungeeCord:
                        // Для BungeeCord используем предопределенные версии
                        return new List<MinecraftVersion>
                        {
                            new MinecraftVersion
                            {
                                Id = "latest",
                                Name = "Latest",
                                ServerType = ServerType.BungeeCord,
                                Type = ServerType.BungeeCord.ToString(),
                                ReleaseDate = DateTime.Now,
                                DownloadUrl = $"{BUNGEECORD_API_URL}lastSuccessfulBuild/artifact/bootstrap/target/BungeeCord.jar"
                            }
                        };
                    case ServerType.NullCordX:
                        // Для NullCordX используем предопределенные версии
                        return new List<MinecraftVersion>
                        {
                            new MinecraftVersion
                            {
                                Id = "latest",
                                Name = "Latest",
                                ServerType = ServerType.NullCordX,
                                Type = ServerType.NullCordX.ToString(),
                                ReleaseDate = DateTime.Now,
                                DownloadUrl = $"{NULLCORDX_API_URL}/latest/download/NullCordX.jar"
                            }
                        };
                    default:
                        return new List<MinecraftVersion>();
                }
                
                try
                {
                    // Для Velocity и Waterfall используем Paper API
                    var response = await _httpClient.GetStringAsync(apiUrl);
                    var data = JsonConvert.DeserializeObject<dynamic>(response);
                    
                    var versions = new List<MinecraftVersion>();
                    
                    try
                    {
                        var buildsResponse = await _httpClient.GetStringAsync($"{apiUrl}/versions/latest");
                        var buildsData = JsonConvert.DeserializeObject<dynamic>(buildsResponse);
                        
                        int latestBuild = buildsData.builds[0];
                        
                        versions.Add(new MinecraftVersion
                        {
                            Id = "latest",
                            Name = "Latest",
                            ServerType = proxyType,
                            Type = proxyType.ToString(),
                            ReleaseDate = DateTime.Now,
                            DownloadUrl = $"{apiUrl}/versions/latest/builds/{latestBuild}/downloads/{prefix}-latest-{latestBuild}.jar"
                        });
                    }
                    catch (Exception ex)
                    {
                        Trace.WriteLine($"Ошибка при получении сборок {proxyType}: {ex.Message}");
                        // Резервный вариант - добавляем запись без точной ссылки
                        versions.Add(new MinecraftVersion
                        {
                            Id = "latest",
                            Name = "Latest",
                            ServerType = proxyType,
                            Type = proxyType.ToString(),
                            ReleaseDate = DateTime.Now,
                            DownloadUrl = $"{apiUrl}"  // Базовый URL для скачивания вручную
                        });
                    }
                    
                    return versions;
                }
                catch (Exception ex)
                {
                    Trace.WriteLine($"Ошибка при работе с API {proxyType}: {ex.Message}");
                    // Возвращаем минимальную версию
                    return new List<MinecraftVersion>
                    {
                        new MinecraftVersion
                        {
                            Id = "latest",
                            Name = "Latest",
                            ServerType = proxyType,
                            Type = proxyType.ToString(),
                            ReleaseDate = DateTime.Now,
                            DownloadUrl = apiUrl  // Базовый URL для скачивания вручную
                        }
                    };
                }
            }
            catch (Exception ex)
            {
                Trace.WriteLine($"Ошибка при получении версий прокси-сервера {proxyType}: {ex.Message}");
                return new List<MinecraftVersion>();
            }
        }

        /// <summary>
        /// Получает все версии со всех источников, группированные по типу ядра, с использованием кэширования
        /// </summary>
        public async Task<Dictionary<string, List<MinecraftVersion>>> GetAllVersionsAsync()
        {
            Trace.WriteLine("[START] Начало загрузки версий серверов...");
            try
            {
                // Проверяем, есть ли актуальные данные в кэше
                await _cacheLock.WaitAsync();
                try
                {
                    if (_versionCache != null && DateTime.Now - _cacheTimestamp < _cacheDuration)
                    {
                        Trace.WriteLine("[CACHE] Используем кэшированные данные версий.");
                        return _versionCache;
                    }
    
                    // Инициализируем результат с пустыми списками для всех типов серверов
                    var result = new Dictionary<string, List<MinecraftVersion>>();
                    Trace.WriteLine("[LOAD] Начинаем загрузку локальных данных о версиях.");
                    
                    // Инициализируем для всех типов сервера пустые списки
                    foreach (ServerType serverType in Enum.GetValues(typeof(ServerType)))
                    {
                        string typeName = serverType.ToString();
                        result[typeName] = new List<MinecraftVersion>();
                    }
                    
                    // Начинаем с локальных данных, которые не требуют сетевых запросов
                    try 
                    {
                        // Заполняем предопределенные версии для серверов, которые не требуют сетевых запросов
                        result[ServerType.Spigot.ToString()] = GetSpigotVersions();
                        result[ServerType.CraftBukkit.ToString()] = GetCraftBukkitVersions();
                        result[ServerType.Forge.ToString()] = GetForgeVersions();
                        result[ServerType.Pufferfish.ToString()] = GetPufferfishVersions();
                        result[ServerType.Leaf.ToString()] = GetLeafVersions();
                        result[ServerType.NeoForge.ToString()] = GetNeoForgeVersions();
                        
                        // Добавляем предопределенные версии для прокси-серверов
                        result[ServerType.BungeeCord.ToString()] = new List<MinecraftVersion>
                        {
                            new MinecraftVersion
                            {
                                Id = "latest",
                                Name = "Latest",
                                ServerType = ServerType.BungeeCord,
                                Type = ServerType.BungeeCord.ToString(),
                                ReleaseDate = DateTime.Now,
                                DownloadUrl = $"{BUNGEECORD_API_URL}lastSuccessfulBuild/artifact/bootstrap/target/BungeeCord.jar"
                            }
                        };
                        
                        result[ServerType.NullCordX.ToString()] = new List<MinecraftVersion>
                        {
                            new MinecraftVersion
                            {
                                Id = "latest",
                                Name = "Latest",
                                ServerType = ServerType.NullCordX,
                                Type = ServerType.NullCordX.ToString(),
                                ReleaseDate = DateTime.Now,
                                DownloadUrl = $"{NULLCORDX_API_URL}/latest/download/NullCordX.jar"
                            }
                        };
                        
                        // Добавляем заглушки для Quilt
                        var defaultQuiltVersions = new List<string> { "1.20.4", "1.20.2", "1.20.1", "1.19.4" };
                        var quiltVersions = new List<MinecraftVersion>();
                        foreach (var v in defaultQuiltVersions)
                        {
                            quiltVersions.Add(new MinecraftVersion
                            {
                                Id = v,
                                Name = $"{v} (Quilt)",
                                ServerType = ServerType.Quilt,
                                Type = ServerType.Quilt.ToString(),
                                ReleaseDate = DateTime.Now,
                                DownloadUrl = $"https://meta.quiltmc.org/v3/versions/loader/{v}/latest/server/jar"
                            });
                        }
                        result[ServerType.Quilt.ToString()] = quiltVersions;
                        
                        // Заглушки для Velocity и Waterfall
                        result[ServerType.Velocity.ToString()] = new List<MinecraftVersion>
                        {
                            new MinecraftVersion
                            {
                                Id = "latest",
                                Name = "Latest",
                                ServerType = ServerType.Velocity,
                                Type = ServerType.Velocity.ToString(),
                                ReleaseDate = DateTime.Now,
                                DownloadUrl = VELOCITY_API_URL
                            }
                        };
                        
                        result[ServerType.Waterfall.ToString()] = new List<MinecraftVersion>
                        {
                            new MinecraftVersion
                            {
                                Id = "latest",
                                Name = "Latest",
                                ServerType = ServerType.Waterfall,
                                Type = ServerType.Waterfall.ToString(),
                                ReleaseDate = DateTime.Now,
                                DownloadUrl = WATERFALL_API_URL
                            }
                        };
                        
                        // Заглушки для Vanilla
                        var vanillaVersions = new List<MinecraftVersion>
                        {
                            new MinecraftVersion
                            {
                                Id = "1.20.4",
                                Name = "1.20.4",
                                Type = "release",
                                ServerType = ServerType.Vanilla,
                                ReleaseDate = DateTime.Now,
                                DownloadUrl = "https://piston-data.mojang.com/v1/objects/8dd1a28015f51b1803213892b50b7b4fc76e594d/server.jar"
                            },
                            new MinecraftVersion
                            {
                                Id = "1.20.2",
                                Name = "1.20.2",
                                Type = "release",
                                ServerType = ServerType.Vanilla,
                                ReleaseDate = DateTime.Now,
                                DownloadUrl = "https://piston-data.mojang.com/v1/objects/5b868151bd02b41319f54c8d4061b5ceb009e7a9/server.jar"
                            },
                            new MinecraftVersion
                            {
                                Id = "1.20.1",
                                Name = "1.20.1",
                                Type = "release",
                                ServerType = ServerType.Vanilla,
                                ReleaseDate = DateTime.Now,
                                DownloadUrl = "https://piston-data.mojang.com/v1/objects/84194a2f286ef7c14ed7ce0090dba59902951553/server.jar"
                            }
                        };
                        result[ServerType.Vanilla.ToString()] = vanillaVersions;
                        
                        // Заглушки для Paper
                        var paperVersions = new List<MinecraftVersion>
                        {
                            new MinecraftVersion
                            {
                                Id = "1.20.4",
                                Name = "1.20.4",
                                ServerType = ServerType.Paper,
                                Type = ServerType.Paper.ToString(),
                                ReleaseDate = DateTime.Now,
                                DownloadUrl = "https://api.papermc.io/v2/projects/paper/versions/1.20.4/builds/376/downloads/paper-1.20.4-376.jar"
                            },
                            new MinecraftVersion
                            {
                                Id = "1.20.2",
                                Name = "1.20.2",
                                ServerType = ServerType.Paper,
                                Type = ServerType.Paper.ToString(),
                                ReleaseDate = DateTime.Now,
                                DownloadUrl = "https://api.papermc.io/v2/projects/paper/versions/1.20.2/builds/309/downloads/paper-1.20.2-309.jar"
                            },
                            new MinecraftVersion
                            {
                                Id = "1.20.1",
                                Name = "1.20.1",
                                ServerType = ServerType.Paper,
                                Type = ServerType.Paper.ToString(),
                                ReleaseDate = DateTime.Now,
                                DownloadUrl = "https://api.papermc.io/v2/projects/paper/versions/1.20.1/builds/196/downloads/paper-1.20.1-196.jar"
                            }
                        };
                        result[ServerType.Paper.ToString()] = paperVersions;
                        
                        // Заглушки для Purpur
                        var purpurVersions = new List<MinecraftVersion>
                        {
                            new MinecraftVersion
                            {
                                Id = "1.20.4",
                                Name = "1.20.4",
                                ServerType = ServerType.Purpur,
                                Type = ServerType.Purpur.ToString(),
                                ReleaseDate = DateTime.Now,
                                DownloadUrl = "https://api.purpurmc.org/v2/purpur/1.20.4/latest/download"
                            },
                            new MinecraftVersion
                            {
                                Id = "1.20.2",
                                Name = "1.20.2",
                                ServerType = ServerType.Purpur,
                                Type = ServerType.Purpur.ToString(),
                                ReleaseDate = DateTime.Now,
                                DownloadUrl = "https://api.purpurmc.org/v2/purpur/1.20.2/latest/download"
                            },
                            new MinecraftVersion
                            {
                                Id = "1.20.1",
                                Name = "1.20.1",
                                ServerType = ServerType.Purpur,
                                Type = ServerType.Purpur.ToString(),
                                ReleaseDate = DateTime.Now,
                                DownloadUrl = "https://api.purpurmc.org/v2/purpur/1.20.1/latest/download"
                            }
                        };
                        result[ServerType.Purpur.ToString()] = purpurVersions;
                        
                        // Заглушки для Fabric
                        var fabricVersions = new List<MinecraftVersion>
                        {
                            new MinecraftVersion
                            {
                                Id = "1.20.4",
                                Name = "1.20.4",
                                ServerType = ServerType.Fabric,
                                Type = ServerType.Fabric.ToString(),
                                ReleaseDate = DateTime.Now,
                                DownloadUrl = "https://meta.fabricmc.net/v2/versions/loader/1.20.4/0.15.3/0.11.2/server/jar"
                            },
                            new MinecraftVersion
                            {
                                Id = "1.20.2",
                                Name = "1.20.2",
                                ServerType = ServerType.Fabric,
                                Type = ServerType.Fabric.ToString(),
                                ReleaseDate = DateTime.Now,
                                DownloadUrl = "https://meta.fabricmc.net/v2/versions/loader/1.20.2/0.15.3/0.11.2/server/jar"
                            },
                            new MinecraftVersion
                            {
                                Id = "1.20.1",
                                Name = "1.20.1",
                                ServerType = ServerType.Fabric,
                                Type = ServerType.Fabric.ToString(),
                                ReleaseDate = DateTime.Now,
                                DownloadUrl = "https://meta.fabricmc.net/v2/versions/loader/1.20.1/0.15.3/0.11.2/server/jar"
                            }
                        };
                        result[ServerType.Fabric.ToString()] = fabricVersions;
                    }
                    catch (Exception ex)
                    {
                        Trace.WriteLine($"Ошибка при получении локальных версий: {ex.Message}");
                    }
                    
                    // Обновляем кэш сразу с предопределенными данными
                    _versionCache = result;
                    _cacheTimestamp = DateTime.Now;
                    Trace.WriteLine("[CACHE] Кэш обновлен локальными данными.");
                    
                    // Запускаем асинхронное обновление данных из сети
                    Trace.WriteLine("[ASYNC] Запускаем фоновое обновление данных из сети.");
                    _ = Task.Run(async () => 
                    {
                        try 
                        {
                            await UpdateVersionsFromNetworkAsync(result);
                        }
                        catch (Exception ex)
                        {
                            Trace.WriteLine($"[ERROR] Ошибка при обновлении версий из сети: {ex.Message}");
                        }
                    });
                    
                    Trace.WriteLine($"[SUCCESS] Загрузка локальных данных успешно завершена. Серверных ядер: {result.Count}");
                    return result;
                }
                finally
                {
                    _cacheLock.Release();
                }
            }
            catch (Exception ex)
            {
                Trace.WriteLine($"[CRITICAL] Глобальная ошибка в GetAllVersionsAsync: {ex.Message}");
                Trace.WriteLine($"[CRITICAL] StackTrace: {ex.StackTrace}");
                return new Dictionary<string, List<MinecraftVersion>>();
            }
        }
        
        /// <summary>
        /// Асинхронно обновляет версии из сети
        /// </summary>
        private async Task UpdateVersionsFromNetworkAsync(Dictionary<string, List<MinecraftVersion>> currentVersions)
        {
            // Ждем небольшую задержку, чтобы не нагружать приложение при запуске
            Trace.WriteLine("[NETWORK] Начинаем задержку перед фоновым обновлением данных...");
            await Task.Delay(5000);
            
            Trace.WriteLine("[NETWORK] Запускаем обновление данных из сети в фоне...");
            try
            {
                // Запускаем все задачи в параллель
                var tasks = new List<Task>();
                
                // Vanilla
                tasks.Add(Task.Run(async () => 
                {
                    try
                    {
                        var vanillaVersions = await GetVanillaVersionsAsync();
                        if (vanillaVersions.Versions.Count > 0)
                        {
                            await _cacheLock.WaitAsync();
                            try
                            {
                                _versionCache[ServerType.Vanilla.ToString()] = vanillaVersions.Versions
                                    .Where(v => v.Type == "release")
                                    .OrderByDescending(v => v.ReleaseDate)
                                    .ToList();
                            }
                            finally
                            {
                                _cacheLock.Release();
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        Trace.WriteLine($"Ошибка при обновлении версий Vanilla: {ex.Message}");
                    }
                }));
                
                // Paper
                tasks.Add(Task.Run(async () => 
                {
                    try
                    {
                        var paperVersions = await GetPaperVersionsAsync();
                        if (paperVersions.Count > 0)
                        {
                            await _cacheLock.WaitAsync();
                            try
                            {
                                _versionCache[ServerType.Paper.ToString()] = paperVersions;
                            }
                            finally
                            {
                                _cacheLock.Release();
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        Trace.WriteLine($"Ошибка при обновлении версий Paper: {ex.Message}");
                    }
                }));
                
                // Purpur
                tasks.Add(Task.Run(async () => 
                {
                    try
                    {
                        var purpurVersions = await GetPurpurVersionsAsync();
                        if (purpurVersions.Count > 0)
                        {
                            await _cacheLock.WaitAsync();
                            try
                            {
                                _versionCache[ServerType.Purpur.ToString()] = purpurVersions;
                            }
                            finally
                            {
                                _cacheLock.Release();
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        Trace.WriteLine($"Ошибка при обновлении версий Purpur: {ex.Message}");
                    }
                }));
                
                // Fabric
                tasks.Add(Task.Run(async () => 
                {
                    try
                    {
                        var fabricVersions = await GetFabricVersionsAsync();
                        if (fabricVersions.Count > 0)
                        {
                            await _cacheLock.WaitAsync();
                            try
                            {
                                _versionCache[ServerType.Fabric.ToString()] = fabricVersions;
                            }
                            finally
                            {
                                _cacheLock.Release();
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        Trace.WriteLine($"Ошибка при обновлении версий Fabric: {ex.Message}");
                    }
                }));
                
                // Quilt
                tasks.Add(Task.Run(async () => 
                {
                    try
                    {
                        var quiltVersions = await GetQuiltVersionsAsync();
                        if (quiltVersions.Count > 0)
                        {
                            await _cacheLock.WaitAsync();
                            try
                            {
                                _versionCache[ServerType.Quilt.ToString()] = quiltVersions;
                            }
                            finally
                            {
                                _cacheLock.Release();
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        Trace.WriteLine($"Ошибка при обновлении версий Quilt: {ex.Message}");
                    }
                }));
                
                // Velocity
                tasks.Add(Task.Run(async () => 
                {
                    try
                    {
                        var velocityVersions = await GetProxyVersionsAsync(ServerType.Velocity);
                        if (velocityVersions.Count > 0)
                        {
                            await _cacheLock.WaitAsync();
                            try
                            {
                                _versionCache[ServerType.Velocity.ToString()] = velocityVersions;
                            }
                            finally
                            {
                                _cacheLock.Release();
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        Trace.WriteLine($"Ошибка при обновлении версий Velocity: {ex.Message}");
                    }
                }));
                
                // Waterfall
                tasks.Add(Task.Run(async () => 
                {
                    try
                    {
                        var waterfallVersions = await GetProxyVersionsAsync(ServerType.Waterfall);
                        if (waterfallVersions.Count > 0)
                        {
                            await _cacheLock.WaitAsync();
                            try
                            {
                                _versionCache[ServerType.Waterfall.ToString()] = waterfallVersions;
                            }
                            finally
                            {
                                _cacheLock.Release();
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        Trace.WriteLine($"Ошибка при обновлении версий Waterfall: {ex.Message}");
                    }
                }));
                
                // Ждем завершения всех задач с большим таймаутом
                Trace.WriteLine("[NETWORK] Ждем завершения фоновых задач...");
                await Task.WhenAny(
                    Task.WhenAll(tasks),
                    Task.Delay(30000) // 30 секунд максимальное время ожидания
                );
                
                // Обновляем временную метку кэша
                _cacheTimestamp = DateTime.Now;
                Trace.WriteLine("[NETWORK] Обновление версий из сети завершено.");
            }
            catch (Exception ex)
            {
                Trace.WriteLine($"[ERROR] Ошибка при обновлении версий из сети: {ex.Message}");
                Trace.WriteLine($"[ERROR] StackTrace: {ex.StackTrace}");
            }
        }
    }
} 