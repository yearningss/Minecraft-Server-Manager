using System;
using System.IO;
using System.Linq;
using System.Collections.Generic;
using System.Threading.Tasks;
using System.Net.Http;
using Newtonsoft.Json;
using MinecraftServerManager.Models;
using MinecraftServerManager.Utils;
using System.Collections.ObjectModel;

namespace MinecraftServerManager.Services
{
    public class ServerCoreService
    {
        private readonly HttpClient _httpClient;
        private readonly VersionService _versionService;
        private Dictionary<string, List<MinecraftVersion>> _availableVersions;
        private bool _isLoading = false;

        // Список предопределенных ядер серверов
        private readonly List<ServerCore> _predefinedCores;

        // Список активных ядер (с доступными версиями)
        private readonly Dictionary<string, ServerCore> _activeCores = new Dictionary<string, ServerCore>();

        public ServerCoreService()
        {
            _httpClient = new HttpClient();
            _httpClient.DefaultRequestHeaders.Add("User-Agent", "MinecraftServerManager/1.0");
            _versionService = new VersionService();
            
            // Инициализируем базовые ядра без версий, которые будут заполнены позже
            _predefinedCores = new List<ServerCore>
            {
                new ServerCore
                {
                    Name = ServerType.Vanilla.ToString(),
                    Type = "Официальное ядро",
                    Description = "Официальное серверное ПО Minecraft от Mojang без модификаций.",
                    LogoUrl = "https://www.minecraft.net/content/dam/minecraft/pack.png"
                },
                new ServerCore
                {
                    Name = ServerType.Paper.ToString(),
                    Type = "Оптимизированное ядро",
                    Description = "Высокопроизводительное ядро для Minecraft серверов с обширными API и улучшениями производительности.",
                    LogoUrl = "https://papermc.io/images/logo.png"
                },
                new ServerCore
                {
                    Name = ServerType.Spigot.ToString(),
                    Type = "Модифицированное ядро",
                    Description = "Популярное ядро для поддержки плагинов Bukkit с улучшениями производительности.",
                    LogoUrl = "https://static.spigotmc.org/img/spigot.png"
                },
                new ServerCore
                {
                    Name = ServerType.Purpur.ToString(),
                    Type = "Оптимизированное ядро",
                    Description = "Форк Paper, нацеленный на улучшение производительности и геймплея.",
                    LogoUrl = "https://purpurmc.org/logo.png"
                },
                new ServerCore
                {
                    Name = ServerType.CraftBukkit.ToString(),
                    Type = "Модифицированное ядро",
                    Description = "Базовое модифицированное ядро Minecraft, поддерживающее API Bukkit для плагинов.",
                    LogoUrl = "https://static.spigotmc.org/img/bukkit.png"
                },
                new ServerCore
                {
                    Name = ServerType.Forge.ToString(),
                    Type = "Модифицированное ядро",
                    Description = "Самое популярное ядро для поддержки модов на Minecraft серверах.",
                    LogoUrl = "https://files.minecraftforge.net/static/images/logo.svg"
                },
                new ServerCore
                {
                    Name = ServerType.Fabric.ToString(),
                    Type = "Модифицированное ядро",
                    Description = "Легковесный и быстрый загрузчик модов для Minecraft серверов.",
                    LogoUrl = "https://fabricmc.net/assets/logo.png"
                },
                // Добавляем новые типы серверов
                new ServerCore
                {
                    Name = ServerType.Pufferfish.ToString(),
                    Type = "Оптимизированное ядро",
                    Description = "Высокопроизводительное ядро, основанное на Paper с дополнительными оптимизациями.",
                    LogoUrl = "https://ci.pufferfish.host/static/logo.png"
                },
                new ServerCore
                {
                    Name = ServerType.Leaf.ToString(),
                    Type = "Оптимизированное ядро",
                    Description = "Оптимизированное ядро для австралийских серверов.",
                    LogoUrl = "https://leaf.une.edu.au/img/logo.png"
                },
                new ServerCore
                {
                    Name = ServerType.Velocity.ToString(),
                    Type = "Прокси-сервер",
                    Description = "Современный прокси-сервер, оптимизированный для производительности.",
                    LogoUrl = "https://velocitypowered.com/img/velocity.png"
                },
                new ServerCore
                {
                    Name = ServerType.NullCordX.ToString(),
                    Type = "Прокси-сервер",
                    Description = "Прокси-сервер для Minecraft с множеством функций.",
                    LogoUrl = "https://github.com/NullCordX/NullCordX/raw/main/logo.png"
                },
                new ServerCore
                {
                    Name = ServerType.BungeeCord.ToString(),
                    Type = "Прокси-сервер",
                    Description = "Классический прокси-сервер для соединения нескольких серверов Minecraft.",
                    LogoUrl = "https://www.spigotmc.org/data/resource_icons/1/1277.jpg"
                },
                new ServerCore
                {
                    Name = ServerType.Waterfall.ToString(),
                    Type = "Прокси-сервер",
                    Description = "Форк BungeeCord от разработчиков Paper, с улучшенной производительностью.",
                    LogoUrl = "https://papermc.io/images/waterfall.png"
                },
                new ServerCore
                {
                    Name = ServerType.Quilt.ToString(),
                    Type = "Модифицированное ядро",
                    Description = "Форк Fabric с улучшенным API и поддержкой модов.",
                    LogoUrl = "https://quiltmc.org/assets/img/logo.svg"
                },
                new ServerCore
                {
                    Name = ServerType.NeoForge.ToString(),
                    Type = "Модифицированное ядро",
                    Description = "Продолжение проекта Forge для новых версий Minecraft.",
                    LogoUrl = "https://neoforged.net/img/logo.png"
                }
            };
            
            // Инициализируем словарь активных ядер
            foreach (var core in _predefinedCores)
            {
                _activeCores.Add(core.Name, core);
            }
        }

        /// <summary>
        /// Получает список доступных версий для всех ядер
        /// </summary>
        public async Task LoadAvailableVersionsAsync()
        {
            if (_isLoading) return; // Предотвращаем параллельную загрузку
            
            _isLoading = true;
            try
            {
                _availableVersions = await _versionService.GetAllVersionsAsync();
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine($"Ошибка при загрузке версий: {ex.Message}");
                _availableVersions = new Dictionary<string, List<MinecraftVersion>>();
            }
            finally
            {
                _isLoading = false;
            }
        }

        /// <summary>
        /// Получает список версий для указанного типа ядра
        /// </summary>
        public List<MinecraftVersion> GetVersionsForCore(string coreName)
        {
            if (_availableVersions == null || !_availableVersions.ContainsKey(coreName))
            {
                return new List<MinecraftVersion>();
            }
            
            return _availableVersions[coreName];
        }

        /// <summary>
        /// Получает список доступных ядер с поддержкой версий
        /// </summary>
        public async Task<List<ServerCore>> GetAvailableCoresAsync()
        {
            // Начинаем загрузку доступных версий (асинхронно)
            Task loadingTask = LoadAvailableVersionsAsync();
            
            // Проверяем, какие ядра уже скачаны
            string serversPath = Path.Combine(App.AppDataPath, "Servers");
            // Создаем директорию, если она не существует
            if (!Directory.Exists(serversPath))
            {
                Directory.CreateDirectory(serversPath);
            }
            var existingFiles = Directory.GetFiles(serversPath, "*.jar").Select(Path.GetFileName).ToList();

            // Возвращаем базовые ядра даже до загрузки версий
            var result = new List<ServerCore>(_predefinedCores);
            
            // Если версии уже загружены, заполняем их
            if (_availableVersions != null)
            {
                UpdateCoresWithVersions(existingFiles);
            }
            
            // Ждем завершения загрузки, но не блокируем возврат базовых ядер
            await loadingTask;
            
            // После завершения загрузки обновляем версии
            if (_availableVersions != null)
            {
                UpdateCoresWithVersions(existingFiles);
            }
            
            return result;
        }

        /// <summary>
        /// Вспомогательный метод для обновления ядер их версиями
        /// </summary>
        private void UpdateCoresWithVersions(List<string> existingFiles)
        {
            foreach (var core in _predefinedCores)
            {
                // Получаем доступные версии для текущего ядра
                var versions = GetVersionsForCore(core.Name);
                core.AvailableVersions = versions;
                
                // Если есть версии, устанавливаем первую как выбранную по умолчанию
                if (versions.Count > 0)
                {
                    // Проверяем, не была ли уже выбрана версия
                    if (core.SelectedVersion == null)
                    {
                        core.SelectedVersion = versions.First();
                        core.Version = versions.First().Name;
                        core.DownloadUrl = versions.First().DownloadUrl;
                    }
                }

                // Проверяем, скачано ли ядро
                core.IsDownloaded = core.SelectedVersion != null && existingFiles.Contains(core.FileName);
            }
        }

        public Task<ServerCore> GetCoreDetailsAsync(string name, string version)
        {
            var core = _predefinedCores.FirstOrDefault(c => c.Name == name);
            if (core != null && !StringUtils.IsNullOrEmpty(version))
            {
                // Находим указанную версию
                var selectedVersion = core.AvailableVersions.FirstOrDefault(v => v.Name == version);
                if (selectedVersion != null)
                {
                    core.SelectedVersion = selectedVersion;
                    core.Version = selectedVersion.Name;
                    core.DownloadUrl = selectedVersion.DownloadUrl;
                }
            }
            return Task.FromResult(core);
        }

        /// <summary>
        /// Обновляет URL скачивания для ядра при изменении выбранной версии
        /// </summary>
        public void UpdateCoreVersion(ServerCore core, MinecraftVersion version)
        {
            if (core != null && version != null)
            {
                core.Version = version.Name;
                core.DownloadUrl = version.DownloadUrl;
                core.SelectedVersion = version;
                
                // Проверяем, скачана ли уже эта версия
                string serversPath = Path.Combine(App.AppDataPath, "Servers");
                if (Directory.Exists(serversPath))
                {
                    var existingFiles = Directory.GetFiles(serversPath, "*.jar").Select(Path.GetFileName).ToList();
                    core.IsDownloaded = existingFiles.Contains(core.FileName);
                }
                else
                {
                    core.IsDownloaded = false;
                }
            }
        }

        public async Task<bool> DownloadCoreAsync(ServerCore core, IProgress<double> progress = null)
        {
            try
            {
                // Проверяем доступность ядра перед загрузкой
                string localFilePath = core.LocalFilePath;
                if (!StringUtils.IsNullOrEmpty(localFilePath) && System.IO.File.Exists(localFilePath))
                {
                    core.IsDownloaded = true;
                }
                
                // Загружаем ядро, если оно еще не загружено
                if (!core.IsDownloaded && !StringUtils.IsNullOrEmpty(core.DownloadUrl))
                {
                    await core.DownloadAsync(progress);
                }
                return core.IsDownloaded;
            }
            catch (Exception ex)
            {
                // Обработка ошибок
                System.Diagnostics.Debug.WriteLine($"Ошибка скачивания ядра: {ex.Message}");
                return false;
            }
        }

        public bool DeleteCore(ServerCore core)
        {
            if (!core.IsDownloaded)
                return false;

            try
            {
                File.Delete(core.LocalFilePath);
                core.IsDownloaded = false;
                return true;
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine($"Ошибка удаления ядра: {ex.Message}");
                return false;
            }
        }
    }
} 