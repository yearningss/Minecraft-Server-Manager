using System;

namespace MinecraftServerManager.Utils
{
    public static class StringUtils
    {
        public static bool IsNullOrEmpty(string value)
        {
            return value == null || value.Length == 0;
        }

        public static bool IsStringNullOrWhiteSpace(string value)
        {
            if (value == null) return true;
            if (value.Length == 0) return true;
            
            foreach (char c in value)
            {
                if (!char.IsWhiteSpace(c))
                {
                    return false;
                }
            }
            
            return true;
        }
    }
} 