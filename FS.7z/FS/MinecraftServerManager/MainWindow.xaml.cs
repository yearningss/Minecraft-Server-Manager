using System;
using System.Windows;
using System.Diagnostics;

namespace MinecraftServerManager
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            try
            {
                Trace.WriteLine("[MAIN-WINDOW] Начало инициализации главного окна");
                
                // Инициализируем компоненты с перехватом исключений
                try
                {
                    InitializeComponent();
                    Trace.WriteLine("[MAIN-WINDOW] Компоненты окна инициализированы");
                }
                catch (Exception compEx)
                {
                    Trace.WriteLine($"[MAIN-WINDOW-ERROR] Ошибка при инициализации компонентов: {compEx.Message}");
                    Trace.WriteLine($"[MAIN-WINDOW-ERROR] StackTrace: {compEx.StackTrace}");
                    MessageBox.Show($"Ошибка при инициализации главного окна: {compEx.Message}\n\nStackTrace: {compEx.StackTrace}",
                        "Ошибка инициализации", MessageBoxButton.OK, MessageBoxImage.Error);
                    throw; // Продолжаем распространение исключения
                }
                
                // Подписываемся на события жизненного цикла окна
                this.Loaded += MainWindow_Loaded;
                this.ContentRendered += MainWindow_ContentRendered;
                this.Closing += MainWindow_Closing;
                this.Closed += MainWindow_Closed;
                
                Trace.WriteLine("[MAIN-WINDOW] Подписка на события жизненного цикла окна выполнена");
            }
            catch (Exception ex)
            {
                Trace.WriteLine($"[MAIN-WINDOW-CRITICAL] Критическая ошибка при инициализации главного окна: {ex.Message}");
                Trace.WriteLine($"[MAIN-WINDOW-CRITICAL] StackTrace: {ex.StackTrace}");
                MessageBox.Show($"Критическая ошибка при инициализации главного окна: {ex.Message}\n\nStackTrace: {ex.StackTrace}",
                    "Критическая ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }
        
        private void MainWindow_Loaded(object sender, RoutedEventArgs e)
        {
            try
            {
                Trace.WriteLine("[MAIN-WINDOW] Событие Loaded вызвано");
                
                // Проверяем инициализацию DataContext
                if (DataContext != null)
                {
                    Trace.WriteLine($"[MAIN-WINDOW] DataContext инициализирован: {DataContext.GetType().Name}");
                }
                else
                {
                    Trace.WriteLine("[MAIN-WINDOW] DataContext не инициализирован");
                }
            }
            catch (Exception ex)
            {
                Trace.WriteLine($"[MAIN-WINDOW-ERROR] Ошибка в обработчике Loaded: {ex.Message}");
                Trace.WriteLine($"[MAIN-WINDOW-ERROR] StackTrace: {ex.StackTrace}");
            }
        }
        
        private void MainWindow_ContentRendered(object sender, EventArgs e)
        {
            try
            {
                Trace.WriteLine("[MAIN-WINDOW] Событие ContentRendered вызвано");
            }
            catch (Exception ex)
            {
                Trace.WriteLine($"[MAIN-WINDOW-ERROR] Ошибка в обработчике ContentRendered: {ex.Message}");
                Trace.WriteLine($"[MAIN-WINDOW-ERROR] StackTrace: {ex.StackTrace}");
            }
        }
        
        private void MainWindow_Closing(object sender, System.ComponentModel.CancelEventArgs e)
        {
            try
            {
                Trace.WriteLine("[MAIN-WINDOW] Событие Closing вызвано");
            }
            catch (Exception ex)
            {
                Trace.WriteLine($"[MAIN-WINDOW-ERROR] Ошибка в обработчике Closing: {ex.Message}");
                Trace.WriteLine($"[MAIN-WINDOW-ERROR] StackTrace: {ex.StackTrace}");
            }
        }
        
        private void MainWindow_Closed(object sender, EventArgs e)
        {
            try
            {
                Trace.WriteLine("[MAIN-WINDOW] Событие Closed вызвано");
            }
            catch (Exception ex)
            {
                Trace.WriteLine($"[MAIN-WINDOW-ERROR] Ошибка в обработчике Closed: {ex.Message}");
                Trace.WriteLine($"[MAIN-WINDOW-ERROR] StackTrace: {ex.StackTrace}");
            }
        }
    }
} 