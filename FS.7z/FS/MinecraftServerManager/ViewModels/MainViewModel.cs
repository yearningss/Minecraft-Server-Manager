using System;
using System.Linq;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Runtime.CompilerServices;
using System.Threading.Tasks;
using System.Windows.Input;
using System.Windows;
using System.Diagnostics;
using System.Windows.Threading;
using MinecraftServerManager.Models;
using MinecraftServerManager.Services;
using MinecraftServerManager.Utils;
using System.Collections.Generic;

namespace MinecraftServerManager.ViewModels
{
    public class MainViewModel : INotifyPropertyChanged
    {
        private readonly ServerCoreService _coreService;
        private readonly ServerInstallService _installService;
        
        private ServerCore _selectedCore;
        private string _selectedServer;
        private bool _isLoading;
        private bool _isLoadingInitialData = true;
        private bool _isLoadingVersions;
        private double _downloadProgress;
        private string _serverName;
        private int _memoryMb = 1024;
        private string _statusText;

        public ObservableCollection<ServerCore> AvailableCores { get; } = new ObservableCollection<ServerCore>();
        public ObservableCollection<string> InstalledServers { get; } = new ObservableCollection<string>();

        public ServerCore SelectedCore
        {
            get => _selectedCore;
            set
            {
                if (_selectedCore != value)
                {
                    _selectedCore = value;
                    OnPropertyChanged();
                    OnPropertyChanged(nameof(IsDownloadEnabled));
                    OnPropertyChanged(nameof(IsDeleteCoreEnabled));
                    OnPropertyChanged(nameof(IsInstallEnabled));
                }
            }
        }

        public string SelectedServer
        {
            get => _selectedServer;
            set
            {
                if (_selectedServer != value)
                {
                    _selectedServer = value;
                    OnPropertyChanged();
                    OnPropertyChanged(nameof(IsLaunchEnabled));
                    OnPropertyChanged(nameof(IsDeleteServerEnabled));
                }
            }
        }

        public bool IsLoading
        {
            get => _isLoading;
            set
            {
                if (_isLoading != value)
                {
                    _isLoading = value;
                    OnPropertyChanged();
                }
            }
        }

        public bool IsLoadingInitialData
        {
            get => _isLoadingInitialData;
            set
            {
                if (_isLoadingInitialData != value)
                {
                    _isLoadingInitialData = value;
                    OnPropertyChanged();
                }
            }
        }

        public bool IsLoadingVersions
        {
            get => _isLoadingVersions;
            set
            {
                if (_isLoadingVersions != value)
                {
                    _isLoadingVersions = value;
                    OnPropertyChanged();
                    
                    // Обновляем статус загрузки
                    if (_isLoadingVersions)
                    {
                        StatusText = "Загрузка версий серверов...";
                    }
                    else if (!_isLoading && !_isLoadingInitialData)
                    {
                        StatusText = "Данные загружены";
                    }
                }
            }
        }

        public double DownloadProgress
        {
            get => _downloadProgress;
            set
            {
                if (_downloadProgress != value)
                {
                    _downloadProgress = value;
                    OnPropertyChanged();
                }
            }
        }

        public string ServerName
        {
            get => _serverName;
            set
            {
                if (_serverName != value)
                {
                    _serverName = value;
                    OnPropertyChanged();
                    OnPropertyChanged(nameof(IsInstallEnabled));
                }
            }
        }

        public int MemoryMb
        {
            get => _memoryMb;
            set
            {
                if (_memoryMb != value)
                {
                    _memoryMb = value;
                    OnPropertyChanged();
                }
            }
        }

        public string StatusText
        {
            get => _statusText;
            set
            {
                if (_statusText != value)
                {
                    _statusText = value;
                    OnPropertyChanged();
                }
            }
        }
        
        // Флаги доступности команд
        public bool IsDownloadEnabled => SelectedCore != null && 
                                       SelectedCore.SelectedVersion != null && 
                                       !SelectedCore.IsDownloaded && 
                                       !SelectedCore.IsDownloading && 
                                       !IsLoadingVersions;
        public bool IsDeleteCoreEnabled => SelectedCore != null && SelectedCore.IsDownloaded && !IsLoadingVersions;
        public bool IsInstallEnabled => SelectedCore != null && SelectedCore.IsDownloaded && !StringUtils.IsStringNullOrWhiteSpace(ServerName) && !IsLoadingVersions;
        public bool IsLaunchEnabled => !StringUtils.IsNullOrEmpty(SelectedServer);
        public bool IsDeleteServerEnabled => !StringUtils.IsNullOrEmpty(SelectedServer);

        // Команды
        public ICommand DownloadCoreCommand { get; }
        public ICommand DeleteCoreCommand { get; }
        public ICommand InstallServerCommand { get; }
        public ICommand LaunchServerCommand { get; }
        public ICommand DeleteServerCommand { get; }
        public ICommand RefreshCommand { get; }
        public ICommand SelectVersionCommand { get; }
        
        public MainViewModel()
        {
            try
            {
                _coreService = new ServerCoreService();
                _installService = new ServerInstallService();

                // Инициализация команд
                DownloadCoreCommand = new RelayCommand(async _ => await DownloadCoreAsync(), _ => !IsLoadingVersions);
                DeleteCoreCommand = new RelayCommand(_ => DeleteCore(), _ => !IsLoadingVersions);
                InstallServerCommand = new RelayCommand(async _ => await InstallServerAsync(), _ => !IsLoadingVersions);
                LaunchServerCommand = new RelayCommand(_ => LaunchServer());
                DeleteServerCommand = new RelayCommand(_ => DeleteServer());
                RefreshCommand = new RelayCommand(async _ => await RefreshDataAsync(), _ => !IsLoadingVersions);
                SelectVersionCommand = new RelayCommand(SelectVersion);

                // Установка начального статуса
                StatusText = "Инициализация приложения...";
                
                // Запуск загрузки данных с задержкой
                Trace.WriteLine("[VIEWMODEL] Инициализация MainViewModel завершена");
                Application.Current.Dispatcher.BeginInvoke(DispatcherPriority.Loaded, new Action(() => {
                    Trace.WriteLine("[VIEWMODEL] Запуск загрузки данных с приоритетом Loaded");
                    Task.Run(InitialLoadAsync);
                }));
            }
            catch (Exception ex)
            {
                Trace.WriteLine($"[VIEWMODEL-ERROR] Ошибка при инициализации MainViewModel: {ex.Message}");
                Trace.WriteLine($"[VIEWMODEL-ERROR] StackTrace: {ex.StackTrace}");
                StatusText = $"Ошибка инициализации: {ex.Message}";
            }
        }

        private async Task InitialLoadAsync()
        {
            try
            {
                IsLoadingInitialData = true;
                StatusText = "Загрузка базовых данных...";
                Trace.WriteLine("[DATA-LOAD] Начало загрузки базовых данных");

                try
                {
                    // Загружаем только список ядер без версий (быстрая операция)
                    var coresWithoutVersions = await _coreService.GetAvailableCoresAsync();
                    Trace.WriteLine($"[DATA-LOAD] Получены базовые данные ядер: {coresWithoutVersions.Count}");
                    
                    // Получаем список установленных серверов (также быстрая операция)
                    var servers = _installService.GetInstalledServers();
                    Trace.WriteLine($"[DATA-LOAD] Получены данные установленных серверов: {servers.Length}");
                    
                    // Обновляем UI с базовыми данными
                    Application.Current.Dispatcher.Invoke(() =>
                    {
                        try
                        {
                            AvailableCores.Clear();
                            foreach (var core in coresWithoutVersions)
                            {
                                AvailableCores.Add(core);
                            }
                            
                            InstalledServers.Clear();
                            foreach (var server in servers)
                            {
                                InstalledServers.Add(server);
                            }
                            
                            Trace.WriteLine("[DATA-LOAD] UI обновлен базовыми данными");
                            IsLoadingInitialData = false;
                            StatusText = "Базовые данные загружены, загрузка версий...";
                        }
                        catch (Exception uiEx)
                        {
                            Trace.WriteLine($"[UI-UPDATE-ERROR] Ошибка при обновлении UI: {uiEx.Message}");
                            Trace.WriteLine($"[UI-UPDATE-ERROR] StackTrace: {uiEx.StackTrace}");
                        }
                    });
                }
                catch (Exception coreEx)
                {
                    Trace.WriteLine($"[CORE-LOAD-ERROR] Ошибка при загрузке базовых данных: {coreEx.Message}");
                    Trace.WriteLine($"[CORE-LOAD-ERROR] StackTrace: {coreEx.StackTrace}");
                    
                    // Продолжаем работу даже при ошибке загрузки ядер
                    Application.Current.Dispatcher.Invoke(() => {
                        IsLoadingInitialData = false;
                        StatusText = "Ошибка загрузки данных. Попробуйте обновить.";
                    });
                    return;
                }
                
                // Добавляем задержку перед загрузкой версий
                await Task.Delay(500);
                
                // Запускаем асинхронную загрузку версий
                try
                {
                    await LoadVersionsAsync();
                }
                catch (Exception versionEx)
                {
                    Trace.WriteLine($"[VERSION-LOAD-ERROR] Ошибка при загрузке версий: {versionEx.Message}");
                    Trace.WriteLine($"[VERSION-LOAD-ERROR] StackTrace: {versionEx.StackTrace}");
                    
                    Application.Current.Dispatcher.Invoke(() => {
                        IsLoadingVersions = false;
                        StatusText = "Ошибка загрузки версий. Приложение работает в ограниченном режиме.";
                    });
                }
            }
            catch (Exception ex)
            {
                Trace.WriteLine($"[DATA-LOAD-ERROR] Глобальная ошибка загрузки данных: {ex.Message}");
                Trace.WriteLine($"[DATA-LOAD-ERROR] StackTrace: {ex.StackTrace}");
                
                Application.Current.Dispatcher.Invoke(() => {
                    StatusText = $"Ошибка загрузки данных: {ex.Message}";
                    IsLoadingInitialData = false;
                    IsLoadingVersions = false;
                });
            }
        }

        private async Task LoadVersionsAsync()
        {
            try
            {
                IsLoadingVersions = true;
                
                // Запускаем обновление версий в фоне (длительная операция с сетевыми запросами)
                await _coreService.LoadAvailableVersionsAsync();
                
                // Обновляем список ядер с версиями
                var cores = await _coreService.GetAvailableCoresAsync();
                
                // Обновляем UI с полными данными
                Application.Current.Dispatcher.Invoke(() =>
                {
                    // Обновляем существующие ядра новыми данными
                    foreach (var core in cores)
                    {
                        var existingCore = AvailableCores.FirstOrDefault(c => c.Name == core.Name);
                        if (existingCore != null)
                        {
                            existingCore.AvailableVersions = core.AvailableVersions;
                            existingCore.SelectedVersion = core.SelectedVersion;
                            existingCore.Version = core.Version;
                            existingCore.DownloadUrl = core.DownloadUrl;
                            existingCore.IsDownloaded = core.IsDownloaded;
                        }
                    }
                    
                    StatusText = "Все данные успешно загружены";
                });
            }
            catch (Exception ex)
            {
                StatusText = $"Ошибка загрузки версий: {ex.Message}";
            }
            finally
            {
                IsLoadingVersions = false;
            }
        }

        private async Task RefreshDataAsync()
        {
            if (IsLoadingVersions) return; // Предотвращаем повторный запуск обновления
            
            try
            {
                IsLoading = true;
                StatusText = "Обновление данных...";

                // Перезагружаем все данные
                await LoadVersionsAsync();
                
                // Получаем список установленных серверов
                var servers = _installService.GetInstalledServers();
                
                Application.Current.Dispatcher.Invoke(() =>
                {
                    InstalledServers.Clear();
                    foreach (var server in servers)
                    {
                        InstalledServers.Add(server);
                    }
                });

                StatusText = "Данные обновлены";
            }
            catch (Exception ex)
            {
                StatusText = $"Ошибка обновления: {ex.Message}";
            }
            finally
            {
                IsLoading = false;
            }
        }

        private async Task DownloadCoreAsync()
        {
            if (SelectedCore == null || SelectedCore.IsDownloaded || SelectedCore.IsDownloading || IsLoadingVersions)
                return;

            try
            {
                StatusText = $"Скачивание ядра {SelectedCore.Name} {SelectedCore.Version}...";
                
                // Создаем объект для передачи прогресса
                var progress = new Progress<double>(p => 
                {
                    DownloadProgress = p;
                    StatusText = $"Скачивание ядра {SelectedCore.Name} {SelectedCore.Version}: {p:P0}";
                });

                await _coreService.DownloadCoreAsync(SelectedCore, progress);
                
                // Обновляем UI
                OnPropertyChanged(nameof(IsDownloadEnabled));
                OnPropertyChanged(nameof(IsDeleteCoreEnabled));
                OnPropertyChanged(nameof(IsInstallEnabled));
                
                StatusText = SelectedCore.IsDownloaded 
                    ? $"Ядро {SelectedCore.Name} {SelectedCore.Version} успешно скачано" 
                    : $"Ошибка при скачивании ядра {SelectedCore.Name} {SelectedCore.Version}";
            }
            catch (Exception ex)
            {
                StatusText = $"Ошибка скачивания: {ex.Message}";
            }
        }

        private void DeleteCore()
        {
            if (SelectedCore == null || !SelectedCore.IsDownloaded || IsLoadingVersions)
                return;

            try
            {
                StatusText = $"Удаление ядра {SelectedCore.Name} {SelectedCore.Version}...";
                
                bool result = _coreService.DeleteCore(SelectedCore);
                
                // Обновляем UI
                OnPropertyChanged(nameof(IsDownloadEnabled));
                OnPropertyChanged(nameof(IsDeleteCoreEnabled));
                OnPropertyChanged(nameof(IsInstallEnabled));
                
                StatusText = result 
                    ? $"Ядро {SelectedCore.Name} {SelectedCore.Version} успешно удалено" 
                    : $"Ошибка при удалении ядра {SelectedCore.Name} {SelectedCore.Version}";
            }
            catch (Exception ex)
            {
                StatusText = $"Ошибка удаления: {ex.Message}";
            }
        }

        private async Task InstallServerAsync()
        {
            if (SelectedCore == null || StringUtils.IsStringNullOrWhiteSpace(ServerName) || IsLoadingVersions)
                return;

            try
            {
                StatusText = $"Установка сервера {ServerName}...";
                
                bool result = await _installService.InstallServerAsync(SelectedCore, ServerName, MemoryMb);
                
                if (result)
                {
                    // Обновляем список установленных серверов
                    var servers = _installService.GetInstalledServers();
                    
                    Application.Current.Dispatcher.Invoke(() =>
                    {
                        InstalledServers.Clear();
                        foreach (var server in servers)
                        {
                            InstalledServers.Add(server);
                        }
                    });
                    
                    StatusText = $"Сервер {ServerName} успешно установлен";
                    ServerName = string.Empty; // Очищаем поле ввода
                }
                else
                {
                    StatusText = $"Ошибка при установке сервера {ServerName}";
                }
            }
            catch (Exception ex)
            {
                StatusText = $"Ошибка установки: {ex.Message}";
            }
        }

        private void LaunchServer()
        {
            if (StringUtils.IsNullOrEmpty(SelectedServer))
                return;

            try
            {
                StatusText = $"Запуск сервера {SelectedServer}...";
                _installService.LaunchServer(SelectedServer);
                StatusText = $"Сервер {SelectedServer} запущен";
            }
            catch (Exception ex)
            {
                StatusText = $"Ошибка запуска: {ex.Message}";
            }
        }

        private void DeleteServer()
        {
            if (StringUtils.IsNullOrEmpty(SelectedServer))
                return;

            try
            {
                StatusText = $"Удаление сервера {SelectedServer}...";
                
                bool result = _installService.DeleteServer(SelectedServer);
                
                if (result)
                {
                    // Обновляем список установленных серверов
                    var servers = _installService.GetInstalledServers();
                    
                    Application.Current.Dispatcher.Invoke(() =>
                    {
                        InstalledServers.Clear();
                        foreach (var server in servers)
                        {
                            InstalledServers.Add(server);
                        }
                    });
                    
                    StatusText = $"Сервер {SelectedServer} успешно удален";
                    SelectedServer = null;
                }
                else
                {
                    StatusText = $"Ошибка при удалении сервера {SelectedServer}";
                }
            }
            catch (Exception ex)
            {
                StatusText = $"Ошибка удаления: {ex.Message}";
            }
        }

        private void SelectVersion(object parameter)
        {
            if (parameter is MinecraftVersion version && SelectedCore != null)
            {
                try 
                {
                    Trace.WriteLine($"[VERSION-SELECT] Выбрана версия: {version.Name} для ядра {SelectedCore.Name}");
                    
                    if (SelectedCore.AvailableVersions != null)
                    {
                        foreach (var v in SelectedCore.AvailableVersions)
                        {
                            if (v != null)
                            {
                                v.IsSelected = false;
                            }
                        }
                    }
                    
                    version.IsSelected = true;
                    SelectedCore.SelectedVersion = version;
                    SelectedCore.Version = version.Name;
                    SelectedCore.DownloadUrl = version.DownloadUrl;
                    
                    // Проверяем, что ядро не скачано
                    SelectedCore.IsDownloaded = false;
                    
                    StatusText = $"Выбрана версия {version.Name} для ядра {SelectedCore.Name}. Начинаем скачивание ядра...";
                    
                    Application.Current.Dispatcher.Invoke(() =>
                    {
                        try
                        {
                            // Обновляем состояние интерфейса на главном потоке UI
                            OnPropertyChanged(nameof(IsDownloadEnabled));
                            OnPropertyChanged(nameof(IsDeleteCoreEnabled));
                            OnPropertyChanged(nameof(IsInstallEnabled));
                            
                            // Вызываем CommandManager.InvalidateRequerySuggested на потоке UI
                            CommandManager.InvalidateRequerySuggested();
                            
                            // Автоматически запускаем скачивание после выбора версии с задержкой
                            Task.Delay(500).ContinueWith(_ => DownloadCoreAsync());
                        }
                        catch (Exception invokeEx)
                        {
                            Trace.WriteLine($"[UI-UPDATE-ERROR] Ошибка при обновлении UI: {invokeEx.Message}");
                            StatusText = $"Ошибка при обновлении интерфейса: {invokeEx.Message}";
                        }
                    });
                }
                catch (Exception ex)
                {
                    Trace.WriteLine($"[VERSION-SELECT-ERROR] Ошибка при выборе версии: {ex.Message}");
                    StatusText = $"Ошибка при выборе версии: {ex.Message}";
                }
            }
            else
            {
                Trace.WriteLine("[VERSION-SELECT-ERROR] Ошибка при выборе версии: Параметр не является допустимой версией или ядро не выбрано");
                StatusText = "Ошибка при выборе версии: Выберите сначала ядро сервера";
            }
        }

        public event PropertyChangedEventHandler PropertyChanged;

        protected virtual void OnPropertyChanged([CallerMemberName] string propertyName = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }

    // Вспомогательный класс для команд WPF
    public class RelayCommand : ICommand
    {
        private readonly Action<object> _execute;
        private readonly Func<object, bool> _canExecute;

        public RelayCommand(Action<object> execute, Func<object, bool> canExecute = null)
        {
            _execute = execute ?? throw new ArgumentNullException(nameof(execute));
            _canExecute = canExecute;
        }

        public bool CanExecute(object parameter)
        {
            return _canExecute == null || _canExecute(parameter);
        }

        public void Execute(object parameter)
        {
            _execute(parameter);
        }

        public event EventHandler CanExecuteChanged
        {
            add { CommandManager.RequerySuggested += value; }
            remove { CommandManager.RequerySuggested -= value; }
        }
    }
} 