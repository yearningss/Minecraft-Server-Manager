using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Runtime.CompilerServices;
using MinecraftServerManager.Utils;

namespace MinecraftServerManager.Models
{
    // Перечисление всех доступных типов серверов Minecraft
    public enum ServerType
    {
        Vanilla,
        Paper,
        Spigot,
        Purpur,
        CraftBukkit,
        Forge,
        Fabric,
        Pufferfish,    // Новое ядро - оптимизированное
        Leaf,           // Новое ядро - оптимизированное для Австралии
        Velocity,       // Прокси-сервер для Paper
        NullCordX,      // Прокси-сервер
        BungeeCord,     // Прокси-сервер
        Waterfall,      // Прокси-сервер, форк BungeeCord
        Quilt,          // Загрузчик модов, форк Fabric
        NeoForge        // Продолжение Forge для новых версий
    }

    public class MinecraftVersion : INotifyPropertyChanged
    {
        private string _id;
        private string _name;
        private string _downloadUrl;
        private string _type;
        private DateTime _releaseDate;
        private bool _isSupported = true;
        private ServerType _serverType = ServerType.Vanilla;
        private bool _isSelected;

        public string Id
        {
            get => _id;
            set
            {
                if (_id != value)
                {
                    _id = value;
                    OnPropertyChanged();
                }
            }
        }

        public string Name
        {
            get => _name;
            set
            {
                if (_name != value)
                {
                    _name = value;
                    OnPropertyChanged();
                    OnPropertyChanged(nameof(DisplayName));
                }
            }
        }

        public string DownloadUrl
        {
            get => _downloadUrl;
            set
            {
                if (_downloadUrl != value)
                {
                    _downloadUrl = value;
                    OnPropertyChanged();
                }
            }
        }

        public string Type
        {
            get => _type;
            set
            {
                if (_type != value)
                {
                    _type = value;
                    OnPropertyChanged();
                    OnPropertyChanged(nameof(DisplayName));
                }
            }
        }

        public ServerType ServerType
        {
            get => _serverType;
            set
            {
                if (_serverType != value)
                {
                    _serverType = value;
                    OnPropertyChanged();
                    OnPropertyChanged(nameof(DisplayName));
                }
            }
        }

        public DateTime ReleaseDate
        {
            get => _releaseDate;
            set
            {
                if (_releaseDate != value)
                {
                    _releaseDate = value;
                    OnPropertyChanged();
                }
            }
        }

        public bool IsSupported
        {
            get => _isSupported;
            set
            {
                if (_isSupported != value)
                {
                    _isSupported = value;
                    OnPropertyChanged();
                }
            }
        }

        public bool IsSelected
        {
            get => _isSelected;
            set
            {
                if (_isSelected != value)
                {
                    _isSelected = value;
                    OnPropertyChanged();
                }
            }
        }

        // Для обратной совместимости (устаревшее свойство)
        public string Version
        {
            get => _name;
            set
            {
                if (_name != value)
                {
                    _name = value;
                    OnPropertyChanged();
                    OnPropertyChanged(nameof(DisplayName));
                }
            }
        }

        // Для отображения в интерфейсе
        public string DisplayName => $"{Name} ({(StringUtils.IsNullOrEmpty(Type) ? ServerType.ToString() : Type)})";

        // Конструктор по умолчанию
        public MinecraftVersion()
        {
        }

        // Конструктор с параметрами
        public MinecraftVersion(string id, string name, string downloadUrl, string type, DateTime releaseDate, bool isSupported = true)
        {
            Id = id;
            Name = name;
            DownloadUrl = downloadUrl;
            Type = type;
            ReleaseDate = releaseDate;
            IsSupported = isSupported;

            // Пытаемся определить тип сервера на основе строкового значения
            if (Enum.TryParse(type, true, out ServerType serverType))
            {
                ServerType = serverType;
            }
        }

        // Новый конструктор с явным указанием ServerType
        public MinecraftVersion(string id, string name, string downloadUrl, ServerType serverType, DateTime releaseDate, bool isSupported = true)
        {
            Id = id;
            Name = name;
            DownloadUrl = downloadUrl;
            ServerType = serverType;
            Type = serverType.ToString(); // Для обратной совместимости
            ReleaseDate = releaseDate;
            IsSupported = isSupported;
        }

        public override string ToString()
        {
            return DisplayName;
        }

        public event PropertyChangedEventHandler PropertyChanged;

        protected virtual void OnPropertyChanged([CallerMemberName] string propertyName = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }

    public class MinecraftVersionInfo
    {
        public List<MinecraftVersion> Versions { get; set; } = new List<MinecraftVersion>();
        public string LatestRelease { get; set; }
        public string LatestSnapshot { get; set; }
    }
} 