using System;
using System.ComponentModel;
using System.Runtime.CompilerServices;

namespace MinecraftServerManager.Models
{
    public class ServerStatus : INotifyPropertyChanged
    {
        private bool _isRunning;
        private string _version;
        private int _playersOnline;
        private int _maxPlayers;
        private string _lastLog;
        private DateTime _startTime;

        public ServerStatus()
        {
            _startTime = DateTime.Now;
        }

        public bool IsRunning
        {
            get => _isRunning;
            set
            {
                if (_isRunning != value)
                {
                    _isRunning = value;
                    OnPropertyChanged();
                    OnPropertyChanged(nameof(StatusText));
                }
            }
        }

        public string Version
        {
            get => _version;
            set
            {
                if (_version != value)
                {
                    _version = value;
                    OnPropertyChanged();
                }
            }
        }

        public int PlayersOnline
        {
            get => _playersOnline;
            set
            {
                if (_playersOnline != value)
                {
                    _playersOnline = value;
                    OnPropertyChanged();
                    OnPropertyChanged(nameof(PlayerInfoText));
                }
            }
        }

        public int MaxPlayers
        {
            get => _maxPlayers;
            set
            {
                if (_maxPlayers != value)
                {
                    _maxPlayers = value;
                    OnPropertyChanged();
                    OnPropertyChanged(nameof(PlayerInfoText));
                }
            }
        }

        public string LastLog
        {
            get => _lastLog;
            set
            {
                if (_lastLog != value)
                {
                    _lastLog = value;
                    OnPropertyChanged();
                }
            }
        }

        public string StatusText => IsRunning ? "Работает" : "Остановлен";

        public string PlayerInfoText => $"Игроки: {PlayersOnline}/{MaxPlayers}";

        public string UptimeText
        {
            get
            {
                TimeSpan uptime = DateTime.Now - _startTime;
                return $"Время работы: {uptime.Hours:D2}:{uptime.Minutes:D2}:{uptime.Seconds:D2}";
            }
        }

        public event PropertyChangedEventHandler PropertyChanged;

        public void OnPropertyChanged([CallerMemberName] string propertyName = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }
} 