using System;
using System.IO;
using System.Threading.Tasks;
using System.Net.Http;
using System.ComponentModel;
using System.Runtime.CompilerServices;
using MinecraftServerManager.Utils;
using System.Collections.Generic;

namespace MinecraftServerManager.Models
{
    public class ServerCore : INotifyPropertyChanged
    {
        private string _name;
        private string _version;
        private string _type;
        private string _downloadUrl;
        private string _description;
        private string _logoUrl;
        private bool _isDownloaded;
        private bool _isDownloading;
        private double _downloadProgress;
        private MinecraftVersion _selectedVersion;
        private List<MinecraftVersion> _availableVersions = new List<MinecraftVersion>();

        public string Name
        {
            get => _name;
            set
            {
                if (_name != value)
                {
                    _name = value;
                    OnPropertyChanged();
                }
            }
        }

        public string Version
        {
            get => _version;
            set
            {
                if (_version != value)
                {
                    _version = value;
                    OnPropertyChanged();
                    OnPropertyChanged(nameof(FileName));
                    OnPropertyChanged(nameof(LocalFilePath));
                }
            }
        }

        public string Type
        {
            get => _type;
            set
            {
                if (_type != value)
                {
                    _type = value;
                    OnPropertyChanged();
                }
            }
        }

        public string DownloadUrl
        {
            get => _downloadUrl;
            set
            {
                if (_downloadUrl != value)
                {
                    _downloadUrl = value;
                    OnPropertyChanged();
                }
            }
        }

        public string Description
        {
            get => _description;
            set
            {
                if (_description != value)
                {
                    _description = value;
                    OnPropertyChanged();
                }
            }
        }

        public string LogoUrl
        {
            get => _logoUrl;
            set
            {
                if (_logoUrl != value)
                {
                    _logoUrl = value;
                    OnPropertyChanged();
                }
            }
        }

        public bool IsDownloaded
        {
            get => _isDownloaded;
            set
            {
                if (_isDownloaded != value)
                {
                    _isDownloaded = value;
                    OnPropertyChanged();
                }
            }
        }

        public bool IsDownloading
        {
            get => _isDownloading;
            set
            {
                if (_isDownloading != value)
                {
                    _isDownloading = value;
                    OnPropertyChanged();
                }
            }
        }

        public double DownloadProgress
        {
            get => _downloadProgress;
            set
            {
                if (_downloadProgress != value)
                {
                    _downloadProgress = value;
                    OnPropertyChanged();
                }
            }
        }

        public MinecraftVersion SelectedVersion
        {
            get => _selectedVersion;
            set
            {
                if (_selectedVersion != value)
                {
                    _selectedVersion = value;
                    OnPropertyChanged();
                }
            }
        }

        public List<MinecraftVersion> AvailableVersions
        {
            get => _availableVersions;
            set
            {
                if (_availableVersions != value)
                {
                    _availableVersions = value;
                    OnPropertyChanged();
                }
            }
        }

        public string FileName => Path.GetFileName(DownloadUrl ?? $"{Name.ToLower()}-{Version}.jar");
        
        public string LocalFilePath => Path.Combine(App.AppDataPath, "Servers", FileName);

        public async Task DownloadAsync(IProgress<double> progress = null)
        {
            if (IsDownloaded || IsDownloading || StringUtils.IsNullOrEmpty(DownloadUrl))
                return;

            IsDownloading = true;
            DownloadProgress = 0;

            try
            {
                // Создаем директорию, если она не существует
                string serversDir = Path.Combine(App.AppDataPath, "Servers");
                if (!Directory.Exists(serversDir))
                {
                    Directory.CreateDirectory(serversDir);
                }

                using (HttpClient client = new HttpClient())
                {
                    client.DefaultRequestHeaders.Add("User-Agent", "MinecraftServerManager/1.0");
                    
                    // Получаем содержимое файла
                    using (var response = await client.GetAsync(DownloadUrl, 
                        System.Net.Http.HttpCompletionOption.ResponseHeadersRead))
                    {
                        response.EnsureSuccessStatusCode();
                        
                        // Получаем общий размер файла
                        var totalBytes = response.Content.Headers.ContentLength ?? -1L;
                        
                        using (var contentStream = await response.Content.ReadAsStreamAsync())
                        using (var fileStream = new FileStream(LocalFilePath, FileMode.Create, FileAccess.Write, FileShare.None, 8192, true))
                        {
                            var buffer = new byte[8192];
                            var totalBytesRead = 0L;
                            var bytesRead = 0;
                            
                            while ((bytesRead = await contentStream.ReadAsync(buffer, 0, buffer.Length)) != 0)
                            {
                                await fileStream.WriteAsync(buffer, 0, bytesRead);
                                
                                totalBytesRead += bytesRead;
                                if (totalBytes != -1 && progress != null)
                                {
                                    // Отправляем прогресс скачивания
                                    var progressValue = (double)totalBytesRead / totalBytes;
                                    DownloadProgress = progressValue;
                                    progress.Report(progressValue);
                                }
                            }
                        }
                    }
                }
                
                IsDownloaded = true;
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine($"Ошибка при скачивании ядра: {ex.Message}");
                throw;
            }
            finally
            {
                IsDownloading = false;
            }
        }

        public event PropertyChangedEventHandler PropertyChanged;

        protected virtual void OnPropertyChanged([CallerMemberName] string propertyName = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }
} 